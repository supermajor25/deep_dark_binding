package net.mcreator.deepdarkbinding.procedures;

public class SunbagEvenementAuClicDroitDansLairProcedure {
	public static void execute() {
	}
}