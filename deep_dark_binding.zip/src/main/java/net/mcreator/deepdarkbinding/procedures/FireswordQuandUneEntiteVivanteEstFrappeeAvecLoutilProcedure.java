package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.entity.Entity;

public class FireswordQuandUneEntiteVivanteEstFrappeeAvecLoutilProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.igniteForSeconds(15);
	}
}