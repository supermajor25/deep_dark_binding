package net.mcreator.deepdarkbinding.procedures;

public class WindarmorEvenementDeTickDesBottesProcedure {
	public static void execute() {
	}
}