package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.entity.Entity;

public class PyriteaxeQuandUneEntiteVivanteEstFrappeeAvecLoutilProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (Math.random() < 0.25) {
			entity.igniteForSeconds(15);
		}
	}
}