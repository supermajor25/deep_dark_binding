package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.deepdarkbinding.init.DeepDarkBindingModPotions;
import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class NauseadynamiterecipeLorsqueLeProjectileToucheUnBlocProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		DeepDarkBindingMod.queueServerWork(60, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 3, Level.ExplosionInteraction.TNT);
			if (world instanceof ServerLevel projectileLevel) {
				Projectile _entityToSpawn = createPotionProjectile(projectileLevel, PotionContents.createItemStack(Items.LINGERING_POTION, DeepDarkBindingModPotions.NAUSEA), null, new Vec3(0, 0, 0));
				_entityToSpawn.setPos(x, y, z);
				_entityToSpawn.shoot(0, (-1), 0, 60, 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		});
	}

	private static Projectile createPotionProjectile(Level level, ItemStack contents, Entity shooter, Vec3 acceleration) {
		ThrownPotion entityToSpawn = new ThrownPotion(EntityType.POTION, level);
		entityToSpawn.setItem(contents);
		return initProjectileProperties(entityToSpawn, shooter, acceleration);
	}

	private static Projectile initProjectileProperties(Projectile entityToSpawn, Entity shooter, Vec3 acceleration) {
		entityToSpawn.setOwner(shooter);
		if (!Vec3.ZERO.equals(acceleration)) {
			entityToSpawn.setDeltaMovement(acceleration);
			entityToSpawn.hasImpulse = true;
		}
		return entityToSpawn;
	}
}