package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.ThrownExperienceBottle;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.EntityType;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class XpdynamiteconfigLorsqueLeProjectileToucheUnBlocProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		DeepDarkBindingMod.queueServerWork(60, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 3, Level.ExplosionInteraction.TNT);
			for (int index0 = 0; index0 < 5; index0++) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = new ThrownExperienceBottle(EntityType.EXPERIENCE_BOTTLE, projectileLevel);
					_entityToSpawn.setPos(x, y, z);
					_entityToSpawn.shoot(0, (-1), 0, 60, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
		});
	}
}