package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

public class Java2Procedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack itemstack = ItemStack.EMPTY;
		Entity sourceentity = null;
		if (getEntityGameType(entity) == GameType.CREATIVE) {
			net.minecraft.world.level.Level world = sourceentity.level();
			double x = sourceentity.getX();
			double y = sourceentity.getY() + 1;
			double z = sourceentity.getZ();
			net.minecraft.nbt.CompoundTag tag = itemstack.getOrDefault(net.minecraft.core.component.DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.EMPTY).copyTag();
			// Le lasso est vide
			if (tag.getInt("Captured") != 1) {
				return;
			}
			String capturedID = tag.getString("CapturedEntity");
			net.minecraft.resources.ResourceLocation id = net.minecraft.resources.ResourceLocation.tryParse(capturedID);
			if (id != null) {
				net.minecraft.world.entity.EntityType<?> type = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.get(id);
				if (type != null) {
					net.minecraft.world.entity.Entity newEntity = type.create(world);
					if (newEntity != null) {
						newEntity.moveTo(x, y, z);
						world.addFreshEntity(newEntity);
						// Vide le lasso
						tag.putInt("Captured", 0);
						tag.remove("CapturedEntity");
						itemstack.set(net.minecraft.core.component.DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(tag));
					}
				}
			}
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}