package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;

public class JavaProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack itemstack = ItemStack.EMPTY;
		Entity targetentity = null;
		Entity sourceentity = null;
		if (entity.isAlive()) {
			net.minecraft.nbt.CompoundTag tag = itemstack.getOrDefault(net.minecraft.core.component.DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.EMPTY).copyTag();
			// Le lasso contient déjà un mob
			if (tag.getInt("Captured") == 1) {
				return;
			}
			// Capture uniquement les animaux
			if (entity instanceof net.minecraft.world.entity.animal.Animal) {
				String capturedID = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
				tag.putInt("Captured", 1);
				tag.putString("CapturedEntity", capturedID);
				itemstack.set(net.minecraft.core.component.DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(tag));
				entity.remove(net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);
			}
		}
	}
}