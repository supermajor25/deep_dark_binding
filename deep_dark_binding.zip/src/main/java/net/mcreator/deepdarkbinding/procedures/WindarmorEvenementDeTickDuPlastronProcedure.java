package net.mcreator.deepdarkbinding.procedures;

public class WindarmorEvenementDeTickDuPlastronProcedure {
	public static void execute() {
	}
}