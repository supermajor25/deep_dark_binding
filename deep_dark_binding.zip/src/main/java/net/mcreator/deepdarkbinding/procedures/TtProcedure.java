package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.monster.Strider;
import net.minecraft.world.entity.animal.sniffer.Sniffer;
import net.minecraft.world.entity.animal.horse.*;
import net.minecraft.world.entity.animal.goat.Goat;
import net.minecraft.world.entity.animal.frog.Frog;
import net.minecraft.world.entity.animal.camel.Camel;
import net.minecraft.world.entity.animal.axolotl.Axolotl;
import net.minecraft.world.entity.animal.armadillo.Armadillo;
import net.minecraft.world.entity.animal.allay.Allay;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.GlowSquid;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.component.DataComponents;

public class TtProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		boolean canCapture = false;
		if (!itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("utilise")) {
			{
				final String _tagName = "utilise";
				final boolean _tagValue = true;
				CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(_tagName, _tagValue));
			}
			if (entity instanceof Chicken) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 1;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Cow) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 2;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Sheep) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 3;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Allay) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 4;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Armadillo) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 5;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Axolotl) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 6;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Bat) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 7;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Bee) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 8;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Camel) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 9;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Cat) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 40;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 10;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof Dolphin) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 11;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Donkey) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 12;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 41;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof Fox) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 13;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof GlowSquid) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 14;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Frog) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 15;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof IronGolem) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 16;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Horse) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 42;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 17;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof Llama) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 43;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 18;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof Goat) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 19;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Mule) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 44;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 20;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof Ocelot) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 21;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof MushroomCow) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 22;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Panda) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 23;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Parrot) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 45;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 24;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof Pig) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 25;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof PolarBear) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 26;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Rabbit) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 27;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof SkeletonHorse) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 28;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Sniffer) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 29;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof SnowGolem) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 30;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Squid) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 31;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Strider) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 32;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof TraderLlama) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 33;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Turtle) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 34;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Villager) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 35;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof Wolf) {
				if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 39;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "valeur";
						final double _tagValue = 36;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				}
			} else if (entity instanceof ZombieHorse) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 37;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else if (entity instanceof WanderingTrader) {
				{
					final String _tagName = "valeur";
					final double _tagValue = 38;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (!entity.level().isClientSide())
					entity.discard();
			} else {
				{
					final String _tagName = "utilise";
					final boolean _tagValue = false;
					CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(_tagName, _tagValue));
				}
			}
		}
	}
}