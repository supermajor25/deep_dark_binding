/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.Minecraft;

import net.mcreator.deepdarkbinding.world.inventory.*;
import net.mcreator.deepdarkbinding.network.MenuStateUpdateMessage;
import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

import java.util.Map;

public class DeepDarkBindingModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, DeepDarkBindingMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<BookMenu>> BOOK = REGISTRY.register("book", () -> IMenuTypeExtension.create(BookMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Page20Menu>> PAGE_20 = REGISTRY.register("page_20", () -> IMenuTypeExtension.create(Page20Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Page30Menu>> PAGE_30 = REGISTRY.register("page_30", () -> IMenuTypeExtension.create(Page30Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Page40Menu>> PAGE_40 = REGISTRY.register("page_40", () -> IMenuTypeExtension.create(Page40Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Page50Menu>> PAGE_50 = REGISTRY.register("page_50", () -> IMenuTypeExtension.create(Page50Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Page60Menu>> PAGE_60 = REGISTRY.register("page_60", () -> IMenuTypeExtension.create(Page60Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Page70Menu>> PAGE_70 = REGISTRY.register("page_70", () -> IMenuTypeExtension.create(Page70Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Sunbagtier1interfaceMenu>> SUNBAGTIER_1INTERFACE = REGISTRY.register("sunbagtier_1interface", () -> IMenuTypeExtension.create(Sunbagtier1interfaceMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Sunbagtier2interfaceMenu>> SUNBAGTIER_2INTERFACE = REGISTRY.register("sunbagtier_2interface", () -> IMenuTypeExtension.create(Sunbagtier2interfaceMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Sunbagtier3interfaceMenu>> SUNBAGTIER_3INTERFACE = REGISTRY.register("sunbagtier_3interface", () -> IMenuTypeExtension.create(Sunbagtier3interfaceMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Sunbagtier4interfaceMenu>> SUNBAGTIER_4INTERFACE = REGISTRY.register("sunbagtier_4interface", () -> IMenuTypeExtension.create(Sunbagtier4interfaceMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Sunbagtier45nterfaceMenu>> SUNBAGTIER_5NTERFACE = REGISTRY.register("sunbagtier_5nterface", () -> IMenuTypeExtension.create(Sunbagtier45nterfaceMenu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				PacketDistributor.sendToPlayer(serverPlayer, new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof DeepDarkBindingModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				PacketDistributor.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}