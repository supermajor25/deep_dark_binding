/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.deepdarkbinding.client.gui.*;

@EventBusSubscriber(Dist.CLIENT)
public class DeepDarkBindingModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(DeepDarkBindingModMenus.BOOK.get(), BookScreen::new);
		event.register(DeepDarkBindingModMenus.PAGE_20.get(), Page20Screen::new);
		event.register(DeepDarkBindingModMenus.PAGE_30.get(), Page30Screen::new);
		event.register(DeepDarkBindingModMenus.PAGE_40.get(), Page40Screen::new);
		event.register(DeepDarkBindingModMenus.PAGE_50.get(), Page50Screen::new);
		event.register(DeepDarkBindingModMenus.PAGE_60.get(), Page60Screen::new);
		event.register(DeepDarkBindingModMenus.PAGE_70.get(), Page70Screen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_1INTERFACE.get(), Sunbagtier1interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_2INTERFACE.get(), Sunbagtier2interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_3INTERFACE.get(), Sunbagtier3interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_4INTERFACE.get(), Sunbagtier4interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_5NTERFACE.get(), Sunbagtier45nterfaceScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}