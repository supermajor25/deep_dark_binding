/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class DeepDarkBindingModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DeepDarkBindingMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DD_BOREANDMISC = REGISTRY.register("dd_boreandmisc",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_dark_binding.dd_boreandmisc")).icon(() -> new ItemStack(DeepDarkBindingModItems.RAWWITHER.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepDarkBindingModItems.ESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.WITHERESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.POISONESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.BLINDNESSESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.WEAKNESSESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.SLOWNESSESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.NAUSEAESSENCEVIAL.get());
				tabData.accept(DeepDarkBindingModItems.WITHERPOWDER.get());
				tabData.accept(DeepDarkBindingModItems.RAWWITHER.get());
				tabData.accept(DeepDarkBindingModItems.RAWPOISON.get());
				tabData.accept(DeepDarkBindingModItems.RAWFIRE.get());
				tabData.accept(DeepDarkBindingModItems.RAWAETHERITE.get());
				tabData.accept(DeepDarkBindingModItems.WITHERINGOT.get());
				tabData.accept(DeepDarkBindingModItems.FIREINGOT.get());
				tabData.accept(DeepDarkBindingModItems.POISONINGOT.get());
				tabData.accept(DeepDarkBindingModItems.INGOTOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.IGNITITEINGOT.get());
				tabData.accept(DeepDarkBindingModItems.NUGGETOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITENUGGET.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITENUGGET.get());
				tabData.accept(DeepDarkBindingModItems.CANETTE.get());
				tabData.accept(DeepDarkBindingModItems.IRONSTRING.get());
				tabData.accept(DeepDarkBindingModItems.DIAMONDSTRING.get());
				tabData.accept(DeepDarkBindingModItems.GOLDSTRING.get());
				tabData.accept(DeepDarkBindingModItems.DARKSTRING.get());
				tabData.accept(DeepDarkBindingModItems.SCRAPIGNITITE.get());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DD_BWEAPONS = REGISTRY.register("dd_bweapons",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_dark_binding.dd_bweapons")).icon(() -> new ItemStack(DeepDarkBindingModItems.SWORDOFWIND.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepDarkBindingModItems.SWORDOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.FIRESWORD.get());
				tabData.accept(DeepDarkBindingModItems.WITHERSWORD.get());
				tabData.accept(DeepDarkBindingModItems.POISONSWORD.get());
				tabData.accept(DeepDarkBindingModItems.KNIFE.get());
				tabData.accept(DeepDarkBindingModItems.DYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.WINDDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.POISONDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.WITHERDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.DRAGONDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.WEAKNESSDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.XPDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.NUKDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.BLINDNESSDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.NAUSEADYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.SLOWNESSDYNAMITE.get());
				tabData.accept(DeepDarkBindingModItems.DYNAMITET_2.get());
				tabData.accept(DeepDarkBindingModItems.DYNAMITET_3.get());
				tabData.accept(DeepDarkBindingModItems.DYNAMITET_4.get());
				tabData.accept(DeepDarkBindingModItems.DYNAMITET_5.get());
				tabData.accept(DeepDarkBindingModItems.WINDARMOR_HELMET.get());
				tabData.accept(DeepDarkBindingModItems.WINDARMOR_CHESTPLATE.get());
				tabData.accept(DeepDarkBindingModItems.WINDARMOR_LEGGINGS.get());
				tabData.accept(DeepDarkBindingModItems.WINDARMOR_BOOTS.get());
				tabData.accept(DeepDarkBindingModItems.IGNIFUE_HELMET.get());
				tabData.accept(DeepDarkBindingModItems.IGNIFUE_CHESTPLATE.get());
				tabData.accept(DeepDarkBindingModItems.IGNIFUE_LEGGINGS.get());
				tabData.accept(DeepDarkBindingModItems.IGNIFUE_BOOTS.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEARMOR_HELMET.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEARMOR_CHESTPLATE.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEARMOR_LEGGINGS.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEARMOR_BOOTS.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITE_HELMET.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITE_CHESTPLATE.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITE_LEGGINGS.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITE_BOOTS.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITE_HELMET.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITE_CHESTPLATE.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITE_LEGGINGS.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITE_BOOTS.get());
			}).withTabsBefore(DD_BOREANDMISC.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DD_BTOOLS = REGISTRY.register("dd_btools",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_dark_binding.dd_btools")).icon(() -> new ItemStack(DeepDarkBindingModItems.PICKAXEOFWIND.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepDarkBindingModItems.DEEPDARKBINDINGBOOK.get());
				tabData.accept(DeepDarkBindingModItems.GOLDEN_LASSO.get());
				tabData.accept(DeepDarkBindingModItems.DARKLASSO.get());
				tabData.accept(DeepDarkBindingModItems.PICKAXEOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.AXEOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.SHOVELOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.HOEOFWIND.get());
				tabData.accept(DeepDarkBindingModItems.SHEAROFWIND.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEPICKAXE.get());
				tabData.accept(DeepDarkBindingModItems.PYRITESHOVEL.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEAXE.get());
				tabData.accept(DeepDarkBindingModItems.PYRITEHOE.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITEAXE.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITESHOVEL.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITEPICKAXE.get());
				tabData.accept(DeepDarkBindingModItems.WITHERITEHOE.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITEAXE.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITEPICKAXE.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITESHOVEL.get());
				tabData.accept(DeepDarkBindingModItems.VENOMITEHOE.get());
				tabData.accept(DeepDarkBindingModItems.SUNBAGTIER_1.get());
				tabData.accept(DeepDarkBindingModItems.SUNBAGTIER_2.get());
				tabData.accept(DeepDarkBindingModItems.SUNBAGTIER_4.get());
				tabData.accept(DeepDarkBindingModItems.SUNBAGTIER_5.get());
				tabData.accept(DeepDarkBindingModItems.SUNBAGTIER3.get());
			}).withTabsBefore(DD_BWEAPONS.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DD_BBLOCK = REGISTRY.register("dd_bblock",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_dark_binding.dd_bblock")).icon(() -> new ItemStack(DeepDarkBindingModBlocks.WINDBLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepDarkBindingModBlocks.PYRITEBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.PYRITERAWBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.PYRITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DEEPSLATEPYRITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.WITHERITEBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.WITHERITERAWBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.WITHERITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DEEPSLATEWITHERITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.WINDBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.RAWAETHERITEBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.AETHERITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DEEPSLATEAETHERITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.VENOMITEBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.RAWVENOMITEBLOCK.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.VENOMITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DEEPSLATEVENOMITEORE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.POISONTNT.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DRAGONTNT.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.WITHERTNT.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.SLOWNESSTNT.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.NAUSEATNT.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.IGNITITEDEBRIS.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.OAKSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.BIRCHSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.SPRUCESPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.CRIMSONSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.CHERRYSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.WARPEDSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.BAMBOOSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.JUNGLESPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.MANGROVESPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DARKOAKSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.ACACIASPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.STONESPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.IRONSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.GOLDSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.DIAMONDSPIKE.get().asItem());
				tabData.accept(DeepDarkBindingModBlocks.NETHERITESPIKE.get().asItem());
			}).withTabsBefore(DD_BTOOLS.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DD_BPLANT = REGISTRY.register("dd_bplant",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_dark_binding.dd_bplant")).icon(() -> new ItemStack(DeepDarkBindingModBlocks.WINDFLOWER.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepDarkBindingModBlocks.WINDFLOWER.get().asItem());
				tabData.accept(DeepDarkBindingModItems.COLASEED.get());
				tabData.accept(DeepDarkBindingModItems.COLALEEF.get());
			}).withTabsBefore(DD_BBLOCK.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DD_BFOOD = REGISTRY.register("dd_bfood",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_dark_binding.dd_bfood")).icon(() -> new ItemStack(DeepDarkBindingModItems.FRESHWATERCAN.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepDarkBindingModItems.MILKBOTTLE.get());
				tabData.accept(DeepDarkBindingModItems.WINDFLOWERSODA.get());
				tabData.accept(DeepDarkBindingModItems.FRESHWATERCAN.get());
				tabData.accept(DeepDarkBindingModItems.DARKESSENCEDRINK.get());
				tabData.accept(DeepDarkBindingModItems.BEERCAN.get());
				tabData.accept(DeepDarkBindingModItems.DRAGONENERGYDRINK.get());
				tabData.accept(DeepDarkBindingModItems.COLACAN.get());
				tabData.accept(DeepDarkBindingModItems.BUTTER.get());
				tabData.accept(DeepDarkBindingModItems.FRENCHHAMSANDWICH.get());
				tabData.accept(DeepDarkBindingModItems.SAUSAGE.get());
				tabData.accept(DeepDarkBindingModItems.COOKEDSAUSAGE.get());
				tabData.accept(DeepDarkBindingModItems.CHEESE.get());
				tabData.accept(DeepDarkBindingModItems.HOTDOG.get());
				tabData.accept(DeepDarkBindingModItems.HAMANDCHEESE.get());
				tabData.accept(DeepDarkBindingModItems.CHOCOLATE.get());
				tabData.accept(DeepDarkBindingModItems.TOMATO.get());
				tabData.accept(DeepDarkBindingModItems.BURGER.get());
				tabData.accept(DeepDarkBindingModItems.FRENCHFRIES.get());
				tabData.accept(DeepDarkBindingModItems.XPAPPLE.get());
			}).withTabsBefore(DD_BPLANT.getId()).build());
}