/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.deepdarkbinding.entity.*;
import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class DeepDarkBindingModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, DeepDarkBindingMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<DynamiteconfigEntity>> DYNAMITECONFIG = register("dynamiteconfig",
			EntityType.Builder.<DynamiteconfigEntity>of(DynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<WinddynamiteconfigEntity>> WINDDYNAMITECONFIG = register("winddynamiteconfig",
			EntityType.Builder.<WinddynamiteconfigEntity>of(WinddynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<PoisondynamiteconfigEntity>> POISONDYNAMITECONFIG = register("poisondynamiteconfig",
			EntityType.Builder.<PoisondynamiteconfigEntity>of(PoisondynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<WitherdynamiteconfigEntity>> WITHERDYNAMITECONFIG = register("witherdynamiteconfig",
			EntityType.Builder.<WitherdynamiteconfigEntity>of(WitherdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<DragondynamiteconfigEntity>> DRAGONDYNAMITECONFIG = register("dragondynamiteconfig",
			EntityType.Builder.<DragondynamiteconfigEntity>of(DragondynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<WeaknessdynamiterecipeEntity>> WEAKNESSDYNAMITERECIPE = register("weaknessdynamiterecipe",
			EntityType.Builder.<WeaknessdynamiterecipeEntity>of(WeaknessdynamiterecipeEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<XpdynamiteconfigEntity>> XPDYNAMITECONFIG = register("xpdynamiteconfig",
			EntityType.Builder.<XpdynamiteconfigEntity>of(XpdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<NukdynamiteconfigEntity>> NUKDYNAMITECONFIG = register("nukdynamiteconfig",
			EntityType.Builder.<NukdynamiteconfigEntity>of(NukdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<BlindnessdynamiteconfigEntity>> BLINDNESSDYNAMITECONFIG = register("blindnessdynamiteconfig",
			EntityType.Builder.<BlindnessdynamiteconfigEntity>of(BlindnessdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<NauseadynamiterecipeEntity>> NAUSEADYNAMITERECIPE = register("nauseadynamiterecipe",
			EntityType.Builder.<NauseadynamiterecipeEntity>of(NauseadynamiterecipeEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<SlownessdynamiteconfigEntity>> SLOWNESSDYNAMITECONFIG = register("slownessdynamiteconfig",
			EntityType.Builder.<SlownessdynamiteconfigEntity>of(SlownessdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet2configEntity>> DYNAMITET_2CONFIG = register("dynamitet_2config",
			EntityType.Builder.<Dynamitet2configEntity>of(Dynamitet2configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet3configEntity>> DYNAMITET_3CONFIG = register("dynamitet_3config",
			EntityType.Builder.<Dynamitet3configEntity>of(Dynamitet3configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet4configEntity>> DYNAMITET_4CONFIG = register("dynamitet_4config",
			EntityType.Builder.<Dynamitet4configEntity>of(Dynamitet4configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet5configEntity>> DYNAMITET_5CONFIG = register("dynamitet_5config",
			EntityType.Builder.<Dynamitet5configEntity>of(Dynamitet5configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}
}