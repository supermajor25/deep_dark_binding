/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.deepdarkbinding.block.*;
import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class DeepDarkBindingModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DeepDarkBindingMod.MODID);
	public static final DeferredBlock<Block> WINDFLOWER;
	public static final DeferredBlock<Block> COLAPLANTESTAGE_0;
	public static final DeferredBlock<Block> COLAPLANTESTAGE_1;
	public static final DeferredBlock<Block> COLAPLANTESTAGE_2;
	public static final DeferredBlock<Block> COLAPLANTESTAGE_3;
	public static final DeferredBlock<Block> COLAPLANTESTAGE_4;
	public static final DeferredBlock<Block> COLAPLANTESTAGE_5;
	public static final DeferredBlock<Block> WINDBLOCK;
	public static final DeferredBlock<Block> PYRITEBLOCK;
	public static final DeferredBlock<Block> PYRITERAWBLOCK;
	public static final DeferredBlock<Block> PYRITEORE;
	public static final DeferredBlock<Block> DEEPSLATEPYRITEORE;
	public static final DeferredBlock<Block> WITHERITEBLOCK;
	public static final DeferredBlock<Block> WITHERITERAWBLOCK;
	public static final DeferredBlock<Block> WITHERITEORE;
	public static final DeferredBlock<Block> DEEPSLATEWITHERITEORE;
	public static final DeferredBlock<Block> AETHERITEORE;
	public static final DeferredBlock<Block> DEEPSLATEAETHERITEORE;
	public static final DeferredBlock<Block> RAWAETHERITEBLOCK;
	public static final DeferredBlock<Block> VENOMITEBLOCK;
	public static final DeferredBlock<Block> VENOMITEORE;
	public static final DeferredBlock<Block> DEEPSLATEVENOMITEORE;
	public static final DeferredBlock<Block> RAWVENOMITEBLOCK;
	public static final DeferredBlock<Block> POISONTNT;
	public static final DeferredBlock<Block> DRAGONTNT;
	public static final DeferredBlock<Block> WITHERTNT;
	public static final DeferredBlock<Block> SLOWNESSTNT;
	public static final DeferredBlock<Block> NAUSEATNT;
	public static final DeferredBlock<Block> IGNITITEDEBRIS;
	public static final DeferredBlock<Block> OAKSPIKE;
	public static final DeferredBlock<Block> BIRCHSPIKE;
	public static final DeferredBlock<Block> SPRUCESPIKE;
	public static final DeferredBlock<Block> CRIMSONSPIKE;
	public static final DeferredBlock<Block> CHERRYSPIKE;
	public static final DeferredBlock<Block> WARPEDSPIKE;
	public static final DeferredBlock<Block> BAMBOOSPIKE;
	public static final DeferredBlock<Block> JUNGLESPIKE;
	public static final DeferredBlock<Block> MANGROVESPIKE;
	public static final DeferredBlock<Block> DARKOAKSPIKE;
	public static final DeferredBlock<Block> ACACIASPIKE;
	public static final DeferredBlock<Block> STONESPIKE;
	public static final DeferredBlock<Block> IRONSPIKE;
	public static final DeferredBlock<Block> GOLDSPIKE;
	public static final DeferredBlock<Block> DIAMONDSPIKE;
	public static final DeferredBlock<Block> NETHERITESPIKE;
	static {
		WINDFLOWER = REGISTRY.register("windflower", WindflowerBlock::new);
		COLAPLANTESTAGE_0 = REGISTRY.register("colaplantestage_0", Colaplantestage0Block::new);
		COLAPLANTESTAGE_1 = REGISTRY.register("colaplantestage_1", Colaplantestage1Block::new);
		COLAPLANTESTAGE_2 = REGISTRY.register("colaplantestage_2", Colaplantestage2Block::new);
		COLAPLANTESTAGE_3 = REGISTRY.register("colaplantestage_3", Colaplantestage3Block::new);
		COLAPLANTESTAGE_4 = REGISTRY.register("colaplantestage_4", Colaplantestage4Block::new);
		COLAPLANTESTAGE_5 = REGISTRY.register("colaplantestage_5", Colaplantestage5Block::new);
		WINDBLOCK = REGISTRY.register("windblock", WindblockBlock::new);
		PYRITEBLOCK = REGISTRY.register("pyriteblock", PyriteblockBlock::new);
		PYRITERAWBLOCK = REGISTRY.register("pyriterawblock", PyriterawblockBlock::new);
		PYRITEORE = REGISTRY.register("pyriteore", PyriteoreBlock::new);
		DEEPSLATEPYRITEORE = REGISTRY.register("deepslatepyriteore", DeepslatepyriteoreBlock::new);
		WITHERITEBLOCK = REGISTRY.register("witheriteblock", WitheriteblockBlock::new);
		WITHERITERAWBLOCK = REGISTRY.register("witheriterawblock", WitheriterawblockBlock::new);
		WITHERITEORE = REGISTRY.register("witheriteore", WitheriteoreBlock::new);
		DEEPSLATEWITHERITEORE = REGISTRY.register("deepslatewitheriteore", DeepslatewitheriteoreBlock::new);
		AETHERITEORE = REGISTRY.register("aetheriteore", AetheriteoreBlock::new);
		DEEPSLATEAETHERITEORE = REGISTRY.register("deepslateaetheriteore", DeepslateaetheriteoreBlock::new);
		RAWAETHERITEBLOCK = REGISTRY.register("rawaetheriteblock", RawaetheriteblockBlock::new);
		VENOMITEBLOCK = REGISTRY.register("venomiteblock", VenomiteblockBlock::new);
		VENOMITEORE = REGISTRY.register("venomiteore", VenomiteoreBlock::new);
		DEEPSLATEVENOMITEORE = REGISTRY.register("deepslatevenomiteore", DeepslatevenomiteoreBlock::new);
		RAWVENOMITEBLOCK = REGISTRY.register("rawvenomiteblock", RawvenomiteblockBlock::new);
		POISONTNT = REGISTRY.register("poisontnt", PoisontntBlock::new);
		DRAGONTNT = REGISTRY.register("dragontnt", DragontntBlock::new);
		WITHERTNT = REGISTRY.register("withertnt", WithertntBlock::new);
		SLOWNESSTNT = REGISTRY.register("slownesstnt", SlownesstntBlock::new);
		NAUSEATNT = REGISTRY.register("nauseatnt", NauseatntBlock::new);
		IGNITITEDEBRIS = REGISTRY.register("ignititedebris", IgnititedebrisBlock::new);
		OAKSPIKE = REGISTRY.register("oakspike", OakspikeBlock::new);
		BIRCHSPIKE = REGISTRY.register("birchspike", BirchspikeBlock::new);
		SPRUCESPIKE = REGISTRY.register("sprucespike", SprucespikeBlock::new);
		CRIMSONSPIKE = REGISTRY.register("crimsonspike", CrimsonspikeBlock::new);
		CHERRYSPIKE = REGISTRY.register("cherryspike", CherryspikeBlock::new);
		WARPEDSPIKE = REGISTRY.register("warpedspike", WarpedspikeBlock::new);
		BAMBOOSPIKE = REGISTRY.register("bamboospike", BamboospikeBlock::new);
		JUNGLESPIKE = REGISTRY.register("junglespike", JunglespikeBlock::new);
		MANGROVESPIKE = REGISTRY.register("mangrovespike", MangrovespikeBlock::new);
		DARKOAKSPIKE = REGISTRY.register("darkoakspike", DarkoakspikeBlock::new);
		ACACIASPIKE = REGISTRY.register("acaciaspike", AcaciaspikeBlock::new);
		STONESPIKE = REGISTRY.register("stonespike", StonespikeBlock::new);
		IRONSPIKE = REGISTRY.register("ironspike", IronspikeBlock::new);
		GOLDSPIKE = REGISTRY.register("goldspike", GoldspikeBlock::new);
		DIAMONDSPIKE = REGISTRY.register("diamondspike", DiamondspikeBlock::new);
		NETHERITESPIKE = REGISTRY.register("netheritespike", NetheritespikeBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}