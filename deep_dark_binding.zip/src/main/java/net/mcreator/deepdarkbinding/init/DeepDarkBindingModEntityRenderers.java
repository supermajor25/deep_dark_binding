/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class DeepDarkBindingModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.WINDDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.POISONDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.WITHERDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DRAGONDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.WEAKNESSDYNAMITERECIPE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.XPDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.NUKDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.BLINDNESSDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.NAUSEADYNAMITERECIPE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.SLOWNESSDYNAMITECONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_2CONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_3CONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_4CONFIG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_5CONFIG.get(), ThrownItemRenderer::new);
	}
}