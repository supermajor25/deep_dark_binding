package net.mcreator.deepdarkbinding.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.deepdarkbinding.world.inventory.Page30Menu;
import net.mcreator.deepdarkbinding.network.Page30ButtonMessage;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class Page30Screen extends AbstractContainerScreen<Page30Menu> implements DeepDarkBindingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_page_precedente;
	private Button button_page_suivant;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("deep_dark_binding:textures/screens/page_30.png");

	public Page30Screen(Page30Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 207;
		this.imageHeight = 104;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_3"), 4, 3, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_vous_avez_deux_lasso"), 4, 12, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_le_golden_lasso"), 4, 21, -6711040, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_pour_capturer_les_mobs"), 4, 30, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_et_le_dark_lasso"), 4, 39, -16777216, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_pour_capturer_les_mobs_agressif"), 4, 57, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_30.label_le_dark_lasso"), 4, 48, -10092442, false);
	}

	@Override
	public void init() {
		super.init();
		button_page_precedente = Button.builder(Component.translatable("gui.deep_dark_binding.page_30.button_page_precedente"), e -> {
			int x = Page30Screen.this.x;
			int y = Page30Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page30ButtonMessage(0, x, y, z));
				Page30ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 4, this.topPos + 75, 103, 20).build();
		this.addRenderableWidget(button_page_precedente);
		button_page_suivant = Button.builder(Component.translatable("gui.deep_dark_binding.page_30.button_page_suivant"), e -> {
			int x = Page30Screen.this.x;
			int y = Page30Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page30ButtonMessage(1, x, y, z));
				Page30ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 112, this.topPos + 75, 87, 20).build();
		this.addRenderableWidget(button_page_suivant);
	}
}