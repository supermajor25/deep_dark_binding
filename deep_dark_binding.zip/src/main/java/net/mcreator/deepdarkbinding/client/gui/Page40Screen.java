package net.mcreator.deepdarkbinding.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.deepdarkbinding.world.inventory.Page40Menu;
import net.mcreator.deepdarkbinding.network.Page40ButtonMessage;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class Page40Screen extends AbstractContainerScreen<Page40Menu> implements DeepDarkBindingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_page_precedente;
	private Button button_pager_suivant;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("deep_dark_binding:textures/screens/page_40.png");

	public Page40Screen(Page40Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 227;
		this.imageHeight = 108;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_40.label_4"), 5, 5, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_40.label_si_une_creature_est_aprivoise"), 5, 14, -16777216, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_40.label_reste_telle_aprivoise_apres_sa"), 5, 23, -16777216, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_40.label_oui_elle_restera_aprivoise_mais"), 5, 41, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_40.label_mais_si_cela_ne_marche_pas"), 5, 50, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_40.label_veuillez_men_faire_part_sur_cur"), 5, 59, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		button_page_precedente = Button.builder(Component.translatable("gui.deep_dark_binding.page_40.button_page_precedente"), e -> {
			int x = Page40Screen.this.x;
			int y = Page40Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page40ButtonMessage(0, x, y, z));
				Page40ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 5, this.topPos + 77, 103, 20).build();
		this.addRenderableWidget(button_page_precedente);
		button_pager_suivant = Button.builder(Component.translatable("gui.deep_dark_binding.page_40.button_pager_suivant"), e -> {
			int x = Page40Screen.this.x;
			int y = Page40Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page40ButtonMessage(1, x, y, z));
				Page40ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 122, this.topPos + 77, 93, 20).build();
		this.addRenderableWidget(button_pager_suivant);
	}
}