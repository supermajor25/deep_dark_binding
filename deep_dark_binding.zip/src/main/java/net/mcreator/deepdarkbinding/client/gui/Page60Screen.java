package net.mcreator.deepdarkbinding.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.deepdarkbinding.world.inventory.Page60Menu;
import net.mcreator.deepdarkbinding.network.Page60ButtonMessage;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class Page60Screen extends AbstractContainerScreen<Page60Menu> implements DeepDarkBindingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_page_precedente;
	private Button button_page_suivant;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("deep_dark_binding:textures/screens/page_60.png");

	public Page60Screen(Page60Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 224;
		this.imageHeight = 226;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_6"), 3, 1, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_recette_du_mod"), 3, 10, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_golden_lasso"), 3, 28, -256, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_il_vous_faudra_4_fil_dor_et_une"), 3, 37, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_le_craft_ressemble_a_celui_dune"), 3, 46, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_livre_guide"), 3, 55, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_il_vous_suffit_dun_livre_et_du"), 3, 64, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_le_craft_se_fait_nimporte_comme"), 3, 73, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_fil_dor"), 3, 91, -256, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_il_vous_faut_6_pepite_dor_et_de"), 3, 100, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_3_pepite_dor_a_droite_et_a_gauc"), 3, 109, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_et_3_ficelle_au_millieux"), 3, 118, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_dark_lasso"), 3, 136, -10092442, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_4_fil_sombre_et_une_laisse"), 3, 145, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_le_craft_est_le_meme_que_le_gold"), 3, 154, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_fil_sombre"), 3, 163, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_6_chair_putrefier_er_3_ficelle"), 3, 172, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_60.label_comme_le_craft_du_fil_dor"), 3, 181, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		button_page_precedente = Button.builder(Component.translatable("gui.deep_dark_binding.page_60.button_page_precedente"), e -> {
			int x = Page60Screen.this.x;
			int y = Page60Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page60ButtonMessage(0, x, y, z));
				Page60ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 3, this.topPos + 199, 103, 20).build();
		this.addRenderableWidget(button_page_precedente);
		button_page_suivant = Button.builder(Component.translatable("gui.deep_dark_binding.page_60.button_page_suivant"), e -> {
			int x = Page60Screen.this.x;
			int y = Page60Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page60ButtonMessage(1, x, y, z));
				Page60ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 120, this.topPos + 199, 87, 20).build();
		this.addRenderableWidget(button_page_suivant);
	}
}