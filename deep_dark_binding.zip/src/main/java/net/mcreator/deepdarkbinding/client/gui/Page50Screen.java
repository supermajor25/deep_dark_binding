package net.mcreator.deepdarkbinding.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.deepdarkbinding.world.inventory.Page50Menu;
import net.mcreator.deepdarkbinding.network.Page50ButtonMessage;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class Page50Screen extends AbstractContainerScreen<Page50Menu> implements DeepDarkBindingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_page_precedente;
	private Button button_page_suivant;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("deep_dark_binding:textures/screens/page_50.png");

	public Page50Screen(Page50Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 205;
		this.imageHeight = 114;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_attention_chose_important"), 3, 17, -52429, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_tout_item_stocke_dans_une_creatu"), 3, 26, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_5"), 3, 8, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_sera_detruie_et_disparaitron"), 3, 35, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_donc_avant_de_capture_une_creatu"), 3, 44, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_retire_tout_ce_que_elle_contient"), 3, 53, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_si_une_creature_a_un_name_tag"), 3, 62, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_50.label_a_la_capture_le_name_tag_dispara"), 3, 71, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		button_page_precedente = Button.builder(Component.translatable("gui.deep_dark_binding.page_50.button_page_precedente"), e -> {
			int x = Page50Screen.this.x;
			int y = Page50Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page50ButtonMessage(0, x, y, z));
				Page50ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 3, this.topPos + 89, 103, 20).build();
		this.addRenderableWidget(button_page_precedente);
		button_page_suivant = Button.builder(Component.translatable("gui.deep_dark_binding.page_50.button_page_suivant"), e -> {
			int x = Page50Screen.this.x;
			int y = Page50Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page50ButtonMessage(1, x, y, z));
				Page50ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 111, this.topPos + 89, 87, 20).build();
		this.addRenderableWidget(button_page_suivant);
	}
}