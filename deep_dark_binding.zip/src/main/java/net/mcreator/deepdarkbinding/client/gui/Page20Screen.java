package net.mcreator.deepdarkbinding.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.deepdarkbinding.world.inventory.Page20Menu;
import net.mcreator.deepdarkbinding.network.Page20ButtonMessage;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class Page20Screen extends AbstractContainerScreen<Page20Menu> implements DeepDarkBindingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_page_suivant;
	private Button button_page_precedente;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("deep_dark_binding:textures/screens/page_20.png");

	public Page20Screen(Page20Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 224;
		this.imageHeight = 117;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_2"), 3, 6, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_comment_ca_fonctionne"), 3, 18, -16777216, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_il_suffit_de_faire_un_clique_gau"), 3, 27, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_pour_capturer_une_entite_et_fair"), 3, 36, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_un_clique_droit_pour_liberer_le"), 3, 45, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_cela_ne_marche_sur_les_creature"), 3, 54, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_donc_mob_passif_et_agressif"), 3, 63, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.page_20.label_si_la_creature_est_aprivoise"), 368, 184, -10027162, false);
	}

	@Override
	public void init() {
		super.init();
		button_page_suivant = Button.builder(Component.translatable("gui.deep_dark_binding.page_20.button_page_suivant"), e -> {
			int x = Page20Screen.this.x;
			int y = Page20Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page20ButtonMessage(0, x, y, z));
				Page20ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 120, this.topPos + 90, 87, 20).build();
		this.addRenderableWidget(button_page_suivant);
		button_page_precedente = Button.builder(Component.translatable("gui.deep_dark_binding.page_20.button_page_precedente"), e -> {
			int x = Page20Screen.this.x;
			int y = Page20Screen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new Page20ButtonMessage(1, x, y, z));
				Page20ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 3, this.topPos + 90, 108, 20).build();
		this.addRenderableWidget(button_page_precedente);
	}
}