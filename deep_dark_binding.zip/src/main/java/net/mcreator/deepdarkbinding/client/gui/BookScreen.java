package net.mcreator.deepdarkbinding.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.deepdarkbinding.world.inventory.BookMenu;
import net.mcreator.deepdarkbinding.network.BookButtonMessage;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class BookScreen extends AbstractContainerScreen<BookMenu> implements DeepDarkBindingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_page_suivant;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("deep_dark_binding:textures/screens/book.png");

	public BookScreen(BookMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 206;
		this.imageHeight = 167;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_empty"), 3, 16, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_attention_les_animaux_avec_inv"), 385, 196, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_avant_de_capturer_une_creature_a"), 362, 236, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_si_la_creature_possede_un_name_t"), 287, 206, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_du_mod_extra_utilitie_qui_malheu"), 3, 25, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_est_malheuresement_bloque_en_11"), 3, 34, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_1"), 6, 4, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_ce_livre_est_le_guide_dutilisat"), 3, 43, -6750157, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_du_mod"), 3, 52, -6750157, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_vous_retrouverer_des_tipsinfo"), 3, 61, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_et_les_recette_du_mod"), 3, 70, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.deep_dark_binding.book.label_merci_de_le_lire"), 3, 79, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		button_page_suivant = Button.builder(Component.translatable("gui.deep_dark_binding.book.button_page_suivant"), e -> {
			int x = BookScreen.this.x;
			int y = BookScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new BookButtonMessage(0, x, y, z));
				BookButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 57, this.topPos + 142, 87, 20).build();
		this.addRenderableWidget(button_page_suivant);
	}
}