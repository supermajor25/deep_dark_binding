package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class HamandcheeseItem extends Item {
	public HamandcheeseItem() {
		super(new Item.Properties().food((new FoodProperties.Builder()).nutrition(9).saturationModifier(7f).build()));
	}
}