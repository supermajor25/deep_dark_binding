package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class GoldenlassofiledItem extends Item {
	public GoldenlassofiledItem() {
		super(new Item.Properties());
	}
}