package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.deepdarkbinding.procedures.PoisontntRedstoneAllumee2Procedure;
import net.mcreator.deepdarkbinding.procedures.PoisontntQuandUnBlocEstToucheParUnProjectileProcedure;
import net.mcreator.deepdarkbinding.procedures.PoisontntQuandLeBlocEstDetruitParUneExplosionProcedure;
import net.mcreator.deepdarkbinding.procedures.PoisontntLorsDunClicDroitSurLeBlocProcedure;

public class PoisontntBlock extends Block {
	public PoisontntBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WET_GRASS).instabreak().replaceable().ignitedByLava());
	}

	@Override
	public boolean canConnectRedstone(BlockState state, BlockGetter world, BlockPos pos, Direction side) {
		return true;
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, BlockPos fromPos, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, fromPos, moving);
		if (world.getBestNeighborSignal(pos) > 0) {
			PoisontntRedstoneAllumee2Procedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		}
	}

	@Override
	public void wasExploded(Level world, BlockPos pos, Explosion e) {
		super.wasExploded(world, pos, e);
		PoisontntQuandLeBlocEstDetruitParUneExplosionProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public void onProjectileHit(Level world, BlockState blockstate, BlockHitResult hit, Projectile entity) {
		PoisontntQuandUnBlocEstToucheParUnProjectileProcedure.execute(world, hit.getBlockPos().getX(), hit.getBlockPos().getY(), hit.getBlockPos().getZ(), entity);
	}

	@Override
	public InteractionResult useWithoutItem(BlockState blockstate, Level world, BlockPos pos, Player entity, BlockHitResult hit) {
		super.useWithoutItem(blockstate, world, pos, entity, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		PoisontntLorsDunClicDroitSurLeBlocProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}