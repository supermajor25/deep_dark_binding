package net.mcreator.deepdarkbinding.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.SectionPos;

import net.mcreator.deepdarkbinding.procedures.Page5Procedure;
import net.mcreator.deepdarkbinding.procedures.Page3Procedure;
import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

@EventBusSubscriber
public record Page40ButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {
	public static final Type<Page40ButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DeepDarkBindingMod.MODID, "page_40_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, Page40ButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, Page40ButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new Page40ButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));

	@Override
	public Type<Page40ButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final Page40ButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		// security measure to prevent arbitrary chunk generation
		if (!world.getChunkSource().hasChunk(SectionPos.blockToSectionCoord(x), SectionPos.blockToSectionCoord(z)))
			return;
		if (buttonID == 0) {

			Page3Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			Page5Procedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DeepDarkBindingMod.addNetworkMessage(Page40ButtonMessage.TYPE, Page40ButtonMessage.STREAM_CODEC, Page40ButtonMessage::handleData);
	}
}