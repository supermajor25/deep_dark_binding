package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class DybamiteentitiLorsDeLapparitionInitialeDeLentiteProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		DeepDarkBindingMod.queueServerWork(80, () -> {
			if (!entity.level().isClientSide())
				entity.discard();
		});
	}
}