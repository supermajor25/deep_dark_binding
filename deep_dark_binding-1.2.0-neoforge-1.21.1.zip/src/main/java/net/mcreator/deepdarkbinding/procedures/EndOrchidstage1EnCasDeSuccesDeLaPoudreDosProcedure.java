package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.deepdarkbinding.init.DeepDarkBindingModBlocks;

public class EndOrchidstage1EnCasDeSuccesDeLaPoudreDosProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (Math.random() < 0.45) {
			world.setBlock(BlockPos.containing(x, y, z), DeepDarkBindingModBlocks.END_ORCHIDSTAGE_2.get().defaultBlockState(), 3);
		}
	}
}