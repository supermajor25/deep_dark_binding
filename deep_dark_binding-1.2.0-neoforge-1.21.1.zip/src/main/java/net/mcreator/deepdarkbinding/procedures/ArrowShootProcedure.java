package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.deepdarkbinding.init.DeepDarkBindingModItems;

public class ArrowShootProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (hasEntityInInventory(entity, new ItemStack(DeepDarkBindingModItems.CHARGED_ARROW.get()))) {
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(DeepDarkBindingModItems.CHARGED_ARROW.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
			}
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}