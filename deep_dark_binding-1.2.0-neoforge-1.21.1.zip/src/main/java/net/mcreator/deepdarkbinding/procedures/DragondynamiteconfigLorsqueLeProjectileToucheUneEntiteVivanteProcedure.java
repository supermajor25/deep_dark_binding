package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.DragonFireball;
import net.minecraft.world.entity.EntityType;
import net.minecraft.server.level.ServerLevel;

public class DragondynamiteconfigLorsqueLeProjectileToucheUneEntiteVivanteProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof Level _level && !_level.isClientSide())
			_level.explode(null, x, y, z, 4, Level.ExplosionInteraction.MOB);
		if (world instanceof ServerLevel projectileLevel) {
			Projectile _entityToSpawn = new DragonFireball(EntityType.DRAGON_FIREBALL, projectileLevel);
			_entityToSpawn.setPos(x, y, z);
			_entityToSpawn.shoot(0, (-1), 0, 60, 0);
			projectileLevel.addFreshEntity(_entityToSpawn);
		}
	}
}