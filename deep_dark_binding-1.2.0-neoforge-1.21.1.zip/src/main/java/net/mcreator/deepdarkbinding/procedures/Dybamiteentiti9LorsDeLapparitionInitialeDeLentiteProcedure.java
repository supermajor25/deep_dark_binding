package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class Dybamiteentiti9LorsDeLapparitionInitialeDeLentiteProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		DeepDarkBindingMod.queueServerWork(240, () -> {
			if (!entity.level().isClientSide())
				entity.discard();
		});
	}
}