package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.deepdarkbinding.init.DeepDarkBindingModBlocks;

public class Colaplantestage4EnCasDeSuccesDeLaPoudreDosProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.setBlock(BlockPos.containing(x, y, z), DeepDarkBindingModBlocks.COLAPLANTESTAGE_5.get().defaultBlockState(), 3);
	}
}