package net.mcreator.deepdarkbinding.procedures;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.breeze.Breeze;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.component.DataComponents;

public class DarklassoQuandUneEntiteVivanteEstFrappeeAvecLoutilProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		boolean canCapture = false;
		if (!itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("utilise")) {
			{
				final String _tagName = "utilise";
				final boolean _tagValue = true;
				CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(_tagName, _tagValue));
			}
			if (entity instanceof Monster) {
				if (entity instanceof Blaze) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 50;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Bogged) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 51;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Breeze) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 52;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof CaveSpider) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 53;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Creeper) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 54;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Drowned) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 55;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof EnderMan) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 56;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Endermite) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 57;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Evoker) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 58;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Ghast) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 59;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Giant) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 60;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Guardian) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 61;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Hoglin) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 62;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Husk) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 63;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Illusioner) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 64;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof MagmaCube) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 65;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Phantom) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 66;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Piglin) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 67;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof PiglinBrute) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 68;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Pillager) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 69;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Ravager) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 70;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Shulker) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 71;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Silverfish) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 72;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Skeleton) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 73;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Slime) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 74;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Spider) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 75;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Vex) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 76;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Vindicator) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 77;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Warden) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 78;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Witch) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 79;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof WitherSkeleton) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 80;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Zombie) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 81;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof ZombieVillager) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 82;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof ZombifiedPiglin) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 83;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof ElderGuardian) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 84;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Stray) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 85;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof Zoglin) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 86;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else if (entity instanceof WitherBoss) {
					{
						final String _tagName = "valeur";
						final double _tagValue = 87;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
					}
					if (!entity.level().isClientSide())
						entity.discard();
				} else {
					{
						final String _tagName = "utilise";
						final boolean _tagValue = false;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(_tagName, _tagValue));
					}
				}
			}
		}
	}
}