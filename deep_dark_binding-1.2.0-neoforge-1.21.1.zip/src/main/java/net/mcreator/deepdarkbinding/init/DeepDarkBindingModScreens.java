/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.deepdarkbinding.client.gui.Sunbagtier4interfaceScreen;
import net.mcreator.deepdarkbinding.client.gui.Sunbagtier45nterfaceScreen;
import net.mcreator.deepdarkbinding.client.gui.Sunbagtier3interfaceScreen;
import net.mcreator.deepdarkbinding.client.gui.Sunbagtier2interfaceScreen;
import net.mcreator.deepdarkbinding.client.gui.Sunbagtier1interfaceScreen;

@EventBusSubscriber(Dist.CLIENT)
public class DeepDarkBindingModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_1INTERFACE.get(), Sunbagtier1interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_2INTERFACE.get(), Sunbagtier2interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_3INTERFACE.get(), Sunbagtier3interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_4INTERFACE.get(), Sunbagtier4interfaceScreen::new);
		event.register(DeepDarkBindingModMenus.SUNBAGTIER_5NTERFACE.get(), Sunbagtier45nterfaceScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}