package net.mcreator.deepdarkbinding.init;

import top.theillusivec4.curios.api.type.capability.ICurio;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.CuriosCapability;

import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.deepdarkbinding.procedures.*;

public class DeepDarkBindingModCuriosCompat {
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public SoundInfo getEquipSound(SlotContext slotContext) {
				return new SoundInfo(DeferredHolder.create(Registries.SOUND_EVENT, ResourceLocation.parse("item.armor.equip_chain")).value(), 1, 1);
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				TteWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RING_OF_VITALITY.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public SoundInfo getEquipSound(SlotContext slotContext) {
				return new SoundInfo(DeferredHolder.create(Registries.SOUND_EVENT, ResourceLocation.parse("item.armor.equip_chain")).value(), 1, 1);
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				MiningWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RINGOFMINING.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public SoundInfo getEquipSound(SlotContext slotContext) {
				return new SoundInfo(DeferredHolder.create(Registries.SOUND_EVENT, ResourceLocation.parse("item.armor.equip_chain")).value(), 1, 1);
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				SpeedWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RING_OF_SPEED.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public SoundInfo getEquipSound(SlotContext slotContext) {
				return new SoundInfo(DeferredHolder.create(Registries.SOUND_EVENT, ResourceLocation.parse("item.armor.equip_chain")).value(), 1, 1);
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				HunterWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RINGOFHUNTER.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public SoundInfo getEquipSound(SlotContext slotContext) {
				return new SoundInfo(DeferredHolder.create(Registries.SOUND_EVENT, ResourceLocation.parse("item.armor.equip_chain")).value(), 1, 1);
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				InvisibilityWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RING_OF_INVISIBILITY.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public SoundInfo getEquipSound(SlotContext slotContext) {
				return new SoundInfo(DeferredHolder.create(Registries.SOUND_EVENT, ResourceLocation.parse("item.armor.equip_chain")).value(), 1, 1);
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				StrenghtWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RINGOFSTRENGHT.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				BreathingWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.RING_OF_WATER.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				AmuletofpuritybaubleWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.AMULETOFPURITY.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public void curioTick(SlotContext slotContext) {
				AmuletofsacredlightbaubleWhileBaubleIsEquippedTickProcedure.execute(slotContext.entity());
			}
		}, DeepDarkBindingModItems.AMULETOFSACREDLIGHT.get());
		event.registerItem(CuriosCapability.ITEM, (stack, context) -> new ICurio() {
			@Override
			public ItemStack getStack() {
				return stack;
			}

			@Override
			public boolean makesPiglinsNeutral(SlotContext slotContext) {
				return true;
			}
		}, DeepDarkBindingModItems.PIGLIN_LORDS_AMULET.get());
	}
}