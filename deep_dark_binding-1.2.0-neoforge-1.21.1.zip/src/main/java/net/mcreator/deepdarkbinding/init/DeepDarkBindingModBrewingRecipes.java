package net.mcreator.deepdarkbinding.init;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.component.DataComponents;

import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.recipe.vanilla.IVanillaRecipeFactory;
import mezz.jei.api.recipe.vanilla.IJeiBrewingRecipe;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.IModPlugin;

import java.util.List;
import java.util.ArrayList;

@JeiPlugin
public class DeepDarkBindingModBrewingRecipes implements IModPlugin {
	@Override
	public ResourceLocation getPluginUid() {
		return ResourceLocation.parse("deep_dark_binding:brewing_recipes");
	}

	@Override
	public void registerRecipes(IRecipeRegistration registration) {
		IVanillaRecipeFactory factory = registration.getVanillaRecipeFactory();
		List<IJeiBrewingRecipe> brewingRecipes = new ArrayList<>();
		ItemStack potion = new ItemStack(Items.POTION);
		ItemStack potion2 = new ItemStack(Items.POTION);
		List<ItemStack> ingredientStack = new ArrayList<>();
		List<ItemStack> inputStack = new ArrayList<>();
		ingredientStack.add(new ItemStack(DeepDarkBindingModItems.WITHERPOWDER.get()));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER));
		potion2.set(DataComponents.POTION_CONTENTS, new PotionContents(DeepDarkBindingModPotions.WITHER));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), potion2.copy()));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Blocks.WITHER_ROSE));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER));
		potion2.set(DataComponents.POTION_CONTENTS, new PotionContents(DeepDarkBindingModPotions.WITHER));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), potion2.copy()));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.WIND_CHARGE));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER));
		potion2.set(DataComponents.POTION_CONTENTS, new PotionContents(DeepDarkBindingModPotions.WIND));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), potion2.copy()));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.BREEZE_ROD));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER));
		potion2.set(DataComponents.POTION_CONTENTS, new PotionContents(DeepDarkBindingModPotions.WIND));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), potion2.copy()));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.WIND_CHARGE));
		inputStack.add(new ItemStack(Blocks.POPPY));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModBlocks.WIND_FLOWER.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.MILK_BUCKET));
		inputStack.add(new ItemStack(Items.GLASS_BOTTLE));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.MILK_BOTTLE.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.ROTTEN_FLESH));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER));
		potion2.set(DataComponents.POTION_CONTENTS, new PotionContents(DeepDarkBindingModPotions.BLINDNESS));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), potion2.copy()));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.ENDER_PEARL));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER));
		potion2.set(DataComponents.POTION_CONTENTS, new PotionContents(DeepDarkBindingModPotions.NAUSEA));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), potion2.copy()));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(DeepDarkBindingModItems.WITHERPOWDER.get()));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.WITHERESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.PUFFERFISH));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.POISONESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.POISONOUS_POTATO));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.POISONESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.BONE));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.WEAKNESSESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.INK_SAC));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.BLINDNESSESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.SNOWBALL));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.SLOWNESSESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.ROTTEN_FLESH));
		inputStack.add(new ItemStack(DeepDarkBindingModItems.ESSENCEVIAL.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(DeepDarkBindingModItems.NAUSEAESSENCEVIAL.get())));
		inputStack.clear();
		ingredientStack.clear();
		registration.addRecipes(RecipeTypes.BREWING, brewingRecipes);
	}
}