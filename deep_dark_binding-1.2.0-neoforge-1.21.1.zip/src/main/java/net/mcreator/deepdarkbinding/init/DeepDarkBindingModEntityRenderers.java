/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.deepdarkbinding.client.renderer.*;

@EventBusSubscriber(Dist.CLIENT)
public class DeepDarkBindingModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITECONFIG.get(), DynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.WINDDYNAMITECONFIG.get(), WinddynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.POISONDYNAMITECONFIG.get(), PoisondynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.WITHERDYNAMITECONFIG.get(), WitherdynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DRAGONDYNAMITECONFIG.get(), DragondynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.WEAKNESSDYNAMITERECIPE.get(), WeaknessdynamiterecipeRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.XPDYNAMITECONFIG.get(), XpdynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.NUKDYNAMITECONFIG.get(), NukdynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.BLINDNESSDYNAMITECONFIG.get(), BlindnessdynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.NAUSEADYNAMITERECIPE.get(), NauseadynamiterecipeRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.SLOWNESSDYNAMITECONFIG.get(), SlownessdynamiteconfigRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_2CONFIG.get(), Dynamitet2configRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_3CONFIG.get(), Dynamitet3configRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_4CONFIG.get(), Dynamitet4configRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYNAMITET_5CONFIG.get(), Dynamitet5configRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.THUNDERBOLT.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.FANGBOLT.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.SPIDERBOLTPROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.SHULKERBOLTPROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI.get(), DybamiteentitiRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_2.get(), Dybamiteentiti2Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_3.get(), Dybamiteentiti3Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_4.get(), Dybamiteentiti4Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_5.get(), Dybamiteentiti5Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_6.get(), Dybamiteentiti6Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_7.get(), Dybamiteentiti7Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_8.get(), Dybamiteentiti8Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_9.get(), Dybamiteentiti9Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_10.get(), Dybamiteentiti10Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_11.get(), Dybamiteentiti11Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_12.get(), Dybamiteentiti12Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_13.get(), Dybamiteentiti13Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_14.get(), Dybamiteentiti14Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DYBAMITEENTITI_15.get(), Dybamiteentiti15Renderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.CHARGED_ARROWPROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.FIREARROX.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepDarkBindingModEntities.DECAYARROWSHOT.get(), ThrownItemRenderer::new);
	}
}