/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.deepdarkbinding.client.model.*;

@EventBusSubscriber(Dist.CLIENT)
public class DeepDarkBindingModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelwater_slime.LAYER_LOCATION, Modelwater_slime::createBodyLayer);
		event.registerLayerDefinition(ModelCharged_Arrowentity.LAYER_LOCATION, ModelCharged_Arrowentity::createBodyLayer);
		event.registerLayerDefinition(Modelfire_zombie.LAYER_LOCATION, Modelfire_zombie::createBodyLayer);
		event.registerLayerDefinition(Modeliceslime2.LAYER_LOCATION, Modeliceslime2::createBodyLayer);
		event.registerLayerDefinition(Modelfire_slime.LAYER_LOCATION, Modelfire_slime::createBodyLayer);
		event.registerLayerDefinition(Modeldynamite.LAYER_LOCATION, Modeldynamite::createBodyLayer);
	}
}