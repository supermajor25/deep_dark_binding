/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

public class DeepDarkBindingModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, DeepDarkBindingMod.MODID);
	public static final DeferredHolder<Potion, Potion> WITHER = REGISTRY.register("wither", () -> new Potion(new MobEffectInstance(MobEffects.WITHER, 200, 1, true, true)));
	public static final DeferredHolder<Potion, Potion> WIND = REGISTRY.register("wind", () -> new Potion(new MobEffectInstance(MobEffects.WIND_CHARGED, 2000, 1, true, true)));
	public static final DeferredHolder<Potion, Potion> NAUSEA = REGISTRY.register("nausea", () -> new Potion(new MobEffectInstance(MobEffects.CONFUSION, 2000, 1, true, true)));
	public static final DeferredHolder<Potion, Potion> BLINDNESS = REGISTRY.register("blindness", () -> new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 200, 0, true, true)));
}