package net.mcreator.deepdarkbinding.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.deepdarkbinding.entity.*;
import net.mcreator.deepdarkbinding.DeepDarkBindingMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DeepDarkBindingModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, DeepDarkBindingMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<DynamiteconfigEntity>> DYNAMITECONFIG = register("dynamiteconfig",
			EntityType.Builder.<DynamiteconfigEntity>of(DynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<WinddynamiteconfigEntity>> WINDDYNAMITECONFIG = register("winddynamiteconfig",
			EntityType.Builder.<WinddynamiteconfigEntity>of(WinddynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<PoisondynamiteconfigEntity>> POISONDYNAMITECONFIG = register("poisondynamiteconfig",
			EntityType.Builder.<PoisondynamiteconfigEntity>of(PoisondynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<WitherdynamiteconfigEntity>> WITHERDYNAMITECONFIG = register("witherdynamiteconfig",
			EntityType.Builder.<WitherdynamiteconfigEntity>of(WitherdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<DragondynamiteconfigEntity>> DRAGONDYNAMITECONFIG = register("dragondynamiteconfig",
			EntityType.Builder.<DragondynamiteconfigEntity>of(DragondynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<WeaknessdynamiterecipeEntity>> WEAKNESSDYNAMITERECIPE = register("weaknessdynamiterecipe",
			EntityType.Builder.<WeaknessdynamiterecipeEntity>of(WeaknessdynamiterecipeEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<XpdynamiteconfigEntity>> XPDYNAMITECONFIG = register("xpdynamiteconfig",
			EntityType.Builder.<XpdynamiteconfigEntity>of(XpdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<NukdynamiteconfigEntity>> NUKDYNAMITECONFIG = register("nukdynamiteconfig",
			EntityType.Builder.<NukdynamiteconfigEntity>of(NukdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<BlindnessdynamiteconfigEntity>> BLINDNESSDYNAMITECONFIG = register("blindnessdynamiteconfig",
			EntityType.Builder.<BlindnessdynamiteconfigEntity>of(BlindnessdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<NauseadynamiterecipeEntity>> NAUSEADYNAMITERECIPE = register("nauseadynamiterecipe",
			EntityType.Builder.<NauseadynamiterecipeEntity>of(NauseadynamiterecipeEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<SlownessdynamiteconfigEntity>> SLOWNESSDYNAMITECONFIG = register("slownessdynamiteconfig",
			EntityType.Builder.<SlownessdynamiteconfigEntity>of(SlownessdynamiteconfigEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet2configEntity>> DYNAMITET_2CONFIG = register("dynamitet_2config",
			EntityType.Builder.<Dynamitet2configEntity>of(Dynamitet2configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet3configEntity>> DYNAMITET_3CONFIG = register("dynamitet_3config",
			EntityType.Builder.<Dynamitet3configEntity>of(Dynamitet3configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet4configEntity>> DYNAMITET_4CONFIG = register("dynamitet_4config",
			EntityType.Builder.<Dynamitet4configEntity>of(Dynamitet4configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Dynamitet5configEntity>> DYNAMITET_5CONFIG = register("dynamitet_5config",
			EntityType.Builder.<Dynamitet5configEntity>of(Dynamitet5configEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<ThunderboltEntity>> THUNDERBOLT = register("thunderbolt",
			EntityType.Builder.<ThunderboltEntity>of(ThunderboltEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<FangboltEntity>> FANGBOLT = register("fangbolt",
			EntityType.Builder.<FangboltEntity>of(FangboltEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<SpiderboltprojectileEntity>> SPIDERBOLTPROJECTILE = register("spiderboltprojectile",
			EntityType.Builder.<SpiderboltprojectileEntity>of(SpiderboltprojectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<ShulkerboltprojectileEntity>> SHULKERBOLTPROJECTILE = register("shulkerboltprojectile",
			EntityType.Builder.<ShulkerboltprojectileEntity>of(ShulkerboltprojectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<DybamiteentitiEntity>> DYBAMITEENTITI = register("dybamiteentiti",
			EntityType.Builder.<DybamiteentitiEntity>of(DybamiteentitiEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti2Entity>> DYBAMITEENTITI_2 = register("dybamiteentiti_2",
			EntityType.Builder.<Dybamiteentiti2Entity>of(Dybamiteentiti2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti3Entity>> DYBAMITEENTITI_3 = register("dybamiteentiti_3",
			EntityType.Builder.<Dybamiteentiti3Entity>of(Dybamiteentiti3Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti4Entity>> DYBAMITEENTITI_4 = register("dybamiteentiti_4",
			EntityType.Builder.<Dybamiteentiti4Entity>of(Dybamiteentiti4Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti5Entity>> DYBAMITEENTITI_5 = register("dybamiteentiti_5",
			EntityType.Builder.<Dybamiteentiti5Entity>of(Dybamiteentiti5Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti6Entity>> DYBAMITEENTITI_6 = register("dybamiteentiti_6",
			EntityType.Builder.<Dybamiteentiti6Entity>of(Dybamiteentiti6Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti7Entity>> DYBAMITEENTITI_7 = register("dybamiteentiti_7",
			EntityType.Builder.<Dybamiteentiti7Entity>of(Dybamiteentiti7Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti8Entity>> DYBAMITEENTITI_8 = register("dybamiteentiti_8",
			EntityType.Builder.<Dybamiteentiti8Entity>of(Dybamiteentiti8Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti9Entity>> DYBAMITEENTITI_9 = register("dybamiteentiti_9",
			EntityType.Builder.<Dybamiteentiti9Entity>of(Dybamiteentiti9Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti10Entity>> DYBAMITEENTITI_10 = register("dybamiteentiti_10",
			EntityType.Builder.<Dybamiteentiti10Entity>of(Dybamiteentiti10Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti11Entity>> DYBAMITEENTITI_11 = register("dybamiteentiti_11",
			EntityType.Builder.<Dybamiteentiti11Entity>of(Dybamiteentiti11Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti12Entity>> DYBAMITEENTITI_12 = register("dybamiteentiti_12",
			EntityType.Builder.<Dybamiteentiti12Entity>of(Dybamiteentiti12Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti13Entity>> DYBAMITEENTITI_13 = register("dybamiteentiti_13",
			EntityType.Builder.<Dybamiteentiti13Entity>of(Dybamiteentiti13Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti14Entity>> DYBAMITEENTITI_14 = register("dybamiteentiti_14",
			EntityType.Builder.<Dybamiteentiti14Entity>of(Dybamiteentiti14Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<Dybamiteentiti15Entity>> DYBAMITEENTITI_15 = register("dybamiteentiti_15",
			EntityType.Builder.<Dybamiteentiti15Entity>of(Dybamiteentiti15Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f)

	);
	public static final DeferredHolder<EntityType<?>, EntityType<ChargedArrowprojectileEntity>> CHARGED_ARROWPROJECTILE = register("charged_arrowprojectile",
			EntityType.Builder.<ChargedArrowprojectileEntity>of(ChargedArrowprojectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<FirearroxEntity>> FIREARROX = register("firearrox",
			EntityType.Builder.<FirearroxEntity>of(FirearroxEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<DecayarrowshotEntity>> DECAYARROWSHOT = register("decayarrowshot",
			EntityType.Builder.<DecayarrowshotEntity>of(DecayarrowshotEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		DybamiteentitiEntity.init(event);
		Dybamiteentiti2Entity.init(event);
		Dybamiteentiti3Entity.init(event);
		Dybamiteentiti4Entity.init(event);
		Dybamiteentiti5Entity.init(event);
		Dybamiteentiti6Entity.init(event);
		Dybamiteentiti7Entity.init(event);
		Dybamiteentiti8Entity.init(event);
		Dybamiteentiti9Entity.init(event);
		Dybamiteentiti10Entity.init(event);
		Dybamiteentiti11Entity.init(event);
		Dybamiteentiti12Entity.init(event);
		Dybamiteentiti13Entity.init(event);
		Dybamiteentiti14Entity.init(event);
		Dybamiteentiti15Entity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DYBAMITEENTITI.get(), DybamiteentitiEntity.createAttributes().build());
		event.put(DYBAMITEENTITI_2.get(), Dybamiteentiti2Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_3.get(), Dybamiteentiti3Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_4.get(), Dybamiteentiti4Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_5.get(), Dybamiteentiti5Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_6.get(), Dybamiteentiti6Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_7.get(), Dybamiteentiti7Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_8.get(), Dybamiteentiti8Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_9.get(), Dybamiteentiti9Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_10.get(), Dybamiteentiti10Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_11.get(), Dybamiteentiti11Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_12.get(), Dybamiteentiti12Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_13.get(), Dybamiteentiti13Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_14.get(), Dybamiteentiti14Entity.createAttributes().build());
		event.put(DYBAMITEENTITI_15.get(), Dybamiteentiti15Entity.createAttributes().build());
	}
}