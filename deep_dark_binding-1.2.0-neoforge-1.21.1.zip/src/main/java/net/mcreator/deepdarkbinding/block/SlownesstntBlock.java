package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.deepdarkbinding.procedures.SlownesstntQuandUnBlocEstToucheParUnProjectileProcedure;
import net.mcreator.deepdarkbinding.procedures.SlownesstntQuandLeBlocEstDetruitParUneExplosionProcedure;

public class SlownesstntBlock extends Block {
	public SlownesstntBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WET_GRASS).instabreak().ignitedByLava());
	}

	@Override
	public boolean canConnectRedstone(BlockState state, BlockGetter world, BlockPos pos, Direction side) {
		return true;
	}

	@Override
	public void wasExploded(Level world, BlockPos pos, Explosion e) {
		super.wasExploded(world, pos, e);
		SlownesstntQuandLeBlocEstDetruitParUneExplosionProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public void onProjectileHit(Level world, BlockState blockstate, BlockHitResult hit, Projectile entity) {
		SlownesstntQuandUnBlocEstToucheParUnProjectileProcedure.execute(world, hit.getBlockPos().getX(), hit.getBlockPos().getY(), hit.getBlockPos().getZ(), entity);
	}
}