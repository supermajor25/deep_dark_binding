package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Blocks;

public class NetherrackStairsBlock extends StairBlock {
	public NetherrackStairsBlock() {
		super(Blocks.AIR.defaultBlockState(), BlockBehaviour.Properties.of().sound(SoundType.NETHERRACK).strength(0.4f).requiresCorrectToolForDrops());
	}

	@Override
	public float getExplosionResistance() {
		return 0.4f;
	}
}