package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class PyriterawblockBlock extends Block {
	public PyriterawblockBlock() {
		super(BlockBehaviour.Properties.of().strength(5f, 6f));
	}
}