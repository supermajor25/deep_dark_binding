package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class WitheriteblockBlock extends Block {
	public WitheriteblockBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(10f, 15f));
	}
}