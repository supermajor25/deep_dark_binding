package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;

public class CryingObsidianWallBlock extends WallBlock {
	public CryingObsidianWallBlock() {
		super(BlockBehaviour.Properties.of().strength(50f, 1200f).lightLevel(blockstate -> 10).requiresCorrectToolForDrops().noOcclusion().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
				.isRedstoneConductor((bs, br, bp) -> false).forceSolidOn());
	}
}