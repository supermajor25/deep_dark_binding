package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SlabBlock;

public class CalciteSlabBlock extends SlabBlock {
	public CalciteSlabBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.CALCITE).strength(0.75f).requiresCorrectToolForDrops());
	}
}