package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class EndstonegrassBlock extends Block {
	public EndstonegrassBlock() {
		super(BlockBehaviour.Properties.of().strength(3f, 9f).requiresCorrectToolForDrops());
	}
}