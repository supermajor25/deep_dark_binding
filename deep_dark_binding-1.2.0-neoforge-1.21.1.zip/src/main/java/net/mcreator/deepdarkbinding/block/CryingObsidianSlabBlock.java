package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SlabBlock;

public class CryingObsidianSlabBlock extends SlabBlock {
	public CryingObsidianSlabBlock() {
		super(BlockBehaviour.Properties.of().strength(50f, 1200f).lightLevel(blockstate -> 10).requiresCorrectToolForDrops().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true));
	}
}