package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.Blocks;

public class ObsidianStairsBlock extends StairBlock {
	public ObsidianStairsBlock() {
		super(Blocks.AIR.defaultBlockState(), BlockBehaviour.Properties.of().strength(50f, 1200f).requiresCorrectToolForDrops());
	}

	@Override
	public float getExplosionResistance() {
		return 1200f;
	}
}