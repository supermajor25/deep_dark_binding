package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class PyriteoreBlock extends Block {
	public PyriteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(4f, 6f));
	}
}