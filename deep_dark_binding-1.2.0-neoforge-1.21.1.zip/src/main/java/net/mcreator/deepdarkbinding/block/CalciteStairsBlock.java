package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Blocks;

public class CalciteStairsBlock extends StairBlock {
	public CalciteStairsBlock() {
		super(Blocks.AIR.defaultBlockState(), BlockBehaviour.Properties.of().sound(SoundType.CALCITE).strength(0.75f).requiresCorrectToolForDrops());
	}

	@Override
	public float getExplosionResistance() {
		return 0.75f;
	}
}