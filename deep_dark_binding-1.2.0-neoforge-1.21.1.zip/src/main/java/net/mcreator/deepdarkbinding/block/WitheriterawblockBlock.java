package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class WitheriterawblockBlock extends Block {
	public WitheriterawblockBlock() {
		super(BlockBehaviour.Properties.of().strength(8f, 10f));
	}
}