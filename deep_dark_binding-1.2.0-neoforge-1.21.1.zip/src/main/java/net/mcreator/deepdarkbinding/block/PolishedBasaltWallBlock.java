package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.SoundType;

public class PolishedBasaltWallBlock extends WallBlock {
	public PolishedBasaltWallBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.BASALT).strength(1.25f, 4.2f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn());
	}
}