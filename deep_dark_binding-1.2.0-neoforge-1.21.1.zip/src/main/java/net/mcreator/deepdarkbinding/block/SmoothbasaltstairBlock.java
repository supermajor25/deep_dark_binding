package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Blocks;

public class SmoothbasaltstairBlock extends StairBlock {
	public SmoothbasaltstairBlock() {
		super(Blocks.AIR.defaultBlockState(), BlockBehaviour.Properties.of().sound(SoundType.BASALT).strength(1.25f, 4.2f).requiresCorrectToolForDrops());
	}

	@Override
	public float getExplosionResistance() {
		return 4.2f;
	}
}