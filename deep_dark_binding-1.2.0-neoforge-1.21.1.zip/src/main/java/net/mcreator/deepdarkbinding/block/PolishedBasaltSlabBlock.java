package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SlabBlock;

public class PolishedBasaltSlabBlock extends SlabBlock {
	public PolishedBasaltSlabBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.BASALT).strength(1.2f, 4.2f));
	}
}