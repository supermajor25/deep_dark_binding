package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class WindblockBlock extends Block {
	public WindblockBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(8f, 12f).requiresCorrectToolForDrops());
	}
}