package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class RawaetheriteblockBlock extends Block {
	public RawaetheriteblockBlock() {
		super(BlockBehaviour.Properties.of().strength(7f, 8f).requiresCorrectToolForDrops());
	}
}