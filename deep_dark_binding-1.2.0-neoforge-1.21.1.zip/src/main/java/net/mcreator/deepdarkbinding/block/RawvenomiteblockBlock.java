package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class RawvenomiteblockBlock extends Block {
	public RawvenomiteblockBlock() {
		super(BlockBehaviour.Properties.of().strength(5.5f, 6f).requiresCorrectToolForDrops());
	}
}