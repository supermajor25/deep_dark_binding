package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class AetheriteoreBlock extends Block {
	public AetheriteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(7f, 8f));
	}
}