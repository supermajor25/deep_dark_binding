package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SlabBlock;

public class ObsidianSlabBlock extends SlabBlock {
	public ObsidianSlabBlock() {
		super(BlockBehaviour.Properties.of().strength(50f, 1200f).requiresCorrectToolForDrops());
	}
}