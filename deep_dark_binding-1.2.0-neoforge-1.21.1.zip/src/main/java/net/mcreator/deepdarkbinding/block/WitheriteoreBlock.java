package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class WitheriteoreBlock extends Block {
	public WitheriteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(8f, 10f));
	}
}