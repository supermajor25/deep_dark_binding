package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class DeepslateaetheriteoreBlock extends Block {
	public DeepslateaetheriteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(8f).requiresCorrectToolForDrops());
	}
}