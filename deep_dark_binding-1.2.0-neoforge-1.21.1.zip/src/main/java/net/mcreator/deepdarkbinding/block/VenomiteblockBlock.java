package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class VenomiteblockBlock extends Block {
	public VenomiteblockBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(6f, 10f).requiresCorrectToolForDrops());
	}
}