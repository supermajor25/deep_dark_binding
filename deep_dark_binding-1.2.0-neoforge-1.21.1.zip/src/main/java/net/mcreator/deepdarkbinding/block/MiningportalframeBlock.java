package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class MiningportalframeBlock extends Block {
	public MiningportalframeBlock() {
		super(BlockBehaviour.Properties.of().strength(50f, 1200f).requiresCorrectToolForDrops());
	}
}