package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class DeepslatevenomiteoreBlock extends Block {
	public DeepslatevenomiteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(6f).requiresCorrectToolForDrops());
	}
}