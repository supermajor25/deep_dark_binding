package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.SoundType;

public class CalciteWallBlock extends WallBlock {
	public CalciteWallBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.CALCITE).strength(0.75f).requiresCorrectToolForDrops().noOcclusion().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn());
	}
}