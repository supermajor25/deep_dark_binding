package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class DeepslatepyriteoreBlock extends Block {
	public DeepslatepyriteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(5f, 6f));
	}
}