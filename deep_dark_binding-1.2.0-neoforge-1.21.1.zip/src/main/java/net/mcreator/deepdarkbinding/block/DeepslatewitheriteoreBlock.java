package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class DeepslatewitheriteoreBlock extends Block {
	public DeepslatewitheriteoreBlock() {
		super(BlockBehaviour.Properties.of().strength(9f, 10f));
	}
}