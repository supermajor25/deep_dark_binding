package net.mcreator.deepdarkbinding.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SlabBlock;

public class EndStoneSlabBlock extends SlabBlock {
	public EndStoneSlabBlock() {
		super(BlockBehaviour.Properties.of().strength(3f, 9f).requiresCorrectToolForDrops());
	}
}