package net.mcreator.deepdarkbinding.event;

import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.nbt.CompoundTag;

import net.mcreator.deepdarkbinding.init.DeepDarkBindingModItems;

@EventBusSubscriber(modid = "deep_dark_binding")
public final class Guidebookv2StartingBookEvents {
	private static final String RECEIVED_TAG = "deep_dark_binding:received_starting_book_guidebookv_2";

	private Guidebookv2StartingBookEvents() {
	}

	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (!(event.getEntity() instanceof ServerPlayer player)) {
			return;
		}
		CompoundTag persistentData = player.getPersistentData();
		if (persistentData.getBoolean(RECEIVED_TAG)) {
			return;
		}
		ItemStack book = new ItemStack(DeepDarkBindingModItems.GUIDEBOOKV_2.get());
		if (!player.getInventory().add(book)) {
			player.drop(book, false);
		}
		persistentData.putBoolean(RECEIVED_TAG, true);
	}

	@SubscribeEvent
	public static void onPlayerClone(PlayerEvent.Clone event) {
		if (event.getOriginal().getPersistentData().getBoolean(RECEIVED_TAG)) {
			event.getEntity().getPersistentData().putBoolean(RECEIVED_TAG, true);
		}
	}
}