package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti2Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti2Renderer extends MobRenderer<Dybamiteentiti2Entity, Modeldynamite<Dybamiteentiti2Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite2.png");

	public Dybamiteentiti2Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti2Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti2Entity entity) {
		return entityTexture;
	}
}