package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti4Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti4Renderer extends MobRenderer<Dybamiteentiti4Entity, Modeldynamite<Dybamiteentiti4Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite5.png");

	public Dybamiteentiti4Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti4Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti4Entity entity) {
		return entityTexture;
	}
}