package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti14Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti14Renderer extends MobRenderer<Dybamiteentiti14Entity, Modeldynamite<Dybamiteentiti14Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite14png.png");

	public Dybamiteentiti14Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti14Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti14Entity entity) {
		return entityTexture;
	}
}