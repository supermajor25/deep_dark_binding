package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti15Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti15Renderer extends MobRenderer<Dybamiteentiti15Entity, Modeldynamite<Dybamiteentiti15Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite15png.png");

	public Dybamiteentiti15Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti15Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti15Entity entity) {
		return entityTexture;
	}
}