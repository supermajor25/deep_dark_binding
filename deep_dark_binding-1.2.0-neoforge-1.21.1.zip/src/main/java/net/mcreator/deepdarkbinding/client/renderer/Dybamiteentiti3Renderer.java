package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti3Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti3Renderer extends MobRenderer<Dybamiteentiti3Entity, Modeldynamite<Dybamiteentiti3Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite4.png");

	public Dybamiteentiti3Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti3Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti3Entity entity) {
		return entityTexture;
	}
}