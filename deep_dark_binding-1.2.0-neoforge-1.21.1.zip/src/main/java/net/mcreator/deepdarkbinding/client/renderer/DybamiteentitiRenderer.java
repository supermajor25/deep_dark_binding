package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.DybamiteentitiEntity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class DybamiteentitiRenderer extends MobRenderer<DybamiteentitiEntity, Modeldynamite<DybamiteentitiEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite.png");

	public DybamiteentitiRenderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<DybamiteentitiEntity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(DybamiteentitiEntity entity) {
		return entityTexture;
	}
}