package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti9Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti9Renderer extends MobRenderer<Dybamiteentiti9Entity, Modeldynamite<Dybamiteentiti9Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite9.png");

	public Dybamiteentiti9Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti9Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti9Entity entity) {
		return entityTexture;
	}
}