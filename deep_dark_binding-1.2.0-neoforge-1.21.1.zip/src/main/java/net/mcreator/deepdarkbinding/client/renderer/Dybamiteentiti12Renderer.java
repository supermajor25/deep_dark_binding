package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti12Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti12Renderer extends MobRenderer<Dybamiteentiti12Entity, Modeldynamite<Dybamiteentiti12Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite12png.png");

	public Dybamiteentiti12Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti12Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti12Entity entity) {
		return entityTexture;
	}
}