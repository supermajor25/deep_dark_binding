package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti8Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti8Renderer extends MobRenderer<Dybamiteentiti8Entity, Modeldynamite<Dybamiteentiti8Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite3.png");

	public Dybamiteentiti8Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti8Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti8Entity entity) {
		return entityTexture;
	}
}