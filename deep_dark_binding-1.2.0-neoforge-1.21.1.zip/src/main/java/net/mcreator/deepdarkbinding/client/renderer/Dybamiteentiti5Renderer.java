package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti5Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti5Renderer extends MobRenderer<Dybamiteentiti5Entity, Modeldynamite<Dybamiteentiti5Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite6.png");

	public Dybamiteentiti5Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti5Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti5Entity entity) {
		return entityTexture;
	}
}