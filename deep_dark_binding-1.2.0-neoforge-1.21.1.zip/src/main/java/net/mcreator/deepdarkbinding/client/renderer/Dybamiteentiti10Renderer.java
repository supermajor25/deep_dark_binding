package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti10Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti10Renderer extends MobRenderer<Dybamiteentiti10Entity, Modeldynamite<Dybamiteentiti10Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite10.png");

	public Dybamiteentiti10Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti10Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti10Entity entity) {
		return entityTexture;
	}
}