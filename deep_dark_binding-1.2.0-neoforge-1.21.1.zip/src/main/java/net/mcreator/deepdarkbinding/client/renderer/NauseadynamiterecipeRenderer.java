package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.mcreator.deepdarkbinding.entity.NauseadynamiterecipeEntity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

import com.mojang.math.Axis;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class NauseadynamiterecipeRenderer extends EntityRenderer<NauseadynamiterecipeEntity> {
	private static final ResourceLocation texture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite3.png");
	private final Modeldynamite model;

	public NauseadynamiterecipeRenderer(EntityRendererProvider.Context context) {
		super(context);
		model = new Modeldynamite(context.bakeLayer(Modeldynamite.LAYER_LOCATION));
	}

	@Override
	public void render(NauseadynamiterecipeEntity entityIn, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource bufferIn, int packedLightIn) {
		VertexConsumer vb = bufferIn.getBuffer(RenderType.entityCutout(this.getTextureLocation(entityIn)));
		poseStack.pushPose();
		poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTicks, entityIn.yRotO, entityIn.getYRot()) - 90));
		poseStack.mulPose(Axis.ZP.rotationDegrees(90 + Mth.lerp(partialTicks, entityIn.xRotO, entityIn.getXRot())));
		model.setupAnim(entityIn, 0, 0, entityIn.tickCount + partialTicks, entityIn.getYRot(), entityIn.getXRot());
		model.renderToBuffer(poseStack, vb, packedLightIn, OverlayTexture.NO_OVERLAY);
		poseStack.popPose();
		super.render(entityIn, entityYaw, partialTicks, poseStack, bufferIn, packedLightIn);
	}

	@Override
	public ResourceLocation getTextureLocation(NauseadynamiterecipeEntity entity) {
		return texture;
	}
}