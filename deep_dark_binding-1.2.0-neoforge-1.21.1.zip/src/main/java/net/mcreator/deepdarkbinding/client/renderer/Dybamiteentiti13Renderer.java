package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti13Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti13Renderer extends MobRenderer<Dybamiteentiti13Entity, Modeldynamite<Dybamiteentiti13Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite13png.png");

	public Dybamiteentiti13Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti13Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti13Entity entity) {
		return entityTexture;
	}
}