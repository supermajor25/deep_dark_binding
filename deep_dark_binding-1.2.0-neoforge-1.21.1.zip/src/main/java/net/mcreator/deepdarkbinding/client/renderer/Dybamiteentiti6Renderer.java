package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti6Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti6Renderer extends MobRenderer<Dybamiteentiti6Entity, Modeldynamite<Dybamiteentiti6Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite7.png");

	public Dybamiteentiti6Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti6Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti6Entity entity) {
		return entityTexture;
	}
}