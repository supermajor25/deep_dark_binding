package net.mcreator.deepdarkbinding.client;

import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.client.Minecraft;

import net.mcreator.deepdarkbinding.item.Guidebookv2Item;
import net.mcreator.deepdarkbinding.client.gui.Guidebookv2BookScreen;

@EventBusSubscriber(modid = "deep_dark_binding", value = Dist.CLIENT)
public final class Guidebookv2BookClientEvents {
	private Guidebookv2BookClientEvents() {
	}

	/**
	 * Open before vanilla block/entity interaction consumes the right click.
	 * This makes guide books behave consistently no matter what the player is looking at.
	 */
	@SubscribeEvent
	public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered event) {
		if (!event.isUseItem())
			return;
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.player == null || minecraft.screen != null)
			return;
		ItemStack stack = minecraft.player.getItemInHand(event.getHand());
		if (stack.getItem() instanceof Guidebookv2Item) {
			minecraft.setScreen(new Guidebookv2BookScreen());
			event.setSwingHand(false);
			event.setCanceled(true);
		}
	}
}