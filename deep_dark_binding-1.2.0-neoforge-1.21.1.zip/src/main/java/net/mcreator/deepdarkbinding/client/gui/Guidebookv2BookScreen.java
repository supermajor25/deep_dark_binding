package net.mcreator.deepdarkbinding.client.gui;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;
import net.minecraft.Util;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.List;
import java.util.Deque;
import java.util.ArrayList;
import java.util.ArrayDeque;

import com.mojang.blaze3d.vertex.PoseStack;

import com.jcraft.jogg.Page;

public class Guidebookv2BookScreen extends Screen {
	private static final int PAGE_W = 256;
	private static final int PAGE_H = 320;
	private static final int SIDEBAR_W = 140;
	private static final int GAP_W = 14;
	private static final int PAD = 5;
	private static final int CONTENT_W = SIDEBAR_W + GAP_W + PAGE_W;
	private static final int DESIGN_W = CONTENT_W + PAD * 2;
	private static final int DESIGN_H = PAGE_H + PAD * 2;
	private static final int DEFAULT_SIZE = 12;
	private static final int CATEGORY_ROWS = 11;
	private static final boolean HIDE_NEXT_ARROW_AT_CATEGORY_END = true;
	private static final Pattern TAG_PATTERN = Pattern.compile("\\[(/?)(b|i|u|s|obf|size|color|url|page)(?:=([^\\]]+))?\\]", Pattern.CASE_INSENSITIVE);
	private static final Category[] CATEGORIES = new Category[]{new Category("69bcc429-c42a-4cd8-a8d6-4b333a678bad", "acceuil", new Page[]{new Page("95f4569a-339f-456c-94dd-ed7a15e3445c", "Page 1", false, new VisualElement[]{
			new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
			new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
			new VisualElement("TEXT", 24, 3, 207, 108, String.join("", new String[]{
					"[size=6]Hello, and thank you for downloading my mod!\n\nThis guidebook contains everything you need to know about Deep Dark Binding, including ores, tools, staves, armor, swords, food, dynamite, and the Mining Dimension.\n\nUse this book to discover the mod's content and learn how to progress through its different features.\n\nGood luck, and enjoy your adventure!\n[/size]"}),
					"CENTER", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
			new VisualElement("BUTTON", 182, 233, 60, 11, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "ores", "65cf72c8-afc5-493e-aebd-e5994b479238", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
			new VisualElement("BUTTON", 96, 233, 60, 10, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "tools", "b06d0a29-0d87-45b9-bc31-3cc8d76048ec", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
			new VisualElement("BUTTON", 183, 262, 61, 10, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "dynamite", "0a6c820d-597d-4933-8ca9-53deff927517", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
			new VisualElement("BUTTON", 21, 234, 60, 11, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "armors", "c54d0643-e58f-4d34-80b6-048f20722843", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
			new VisualElement("BUTTON", 19, 262, 60, 11, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "swords", "1bedde13-2227-4d2e-97a8-f0d987a73e88", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
			new VisualElement("BUTTON", 88, 262, 81, 11, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "mining_dimension", "79dba7d7-9aa6-435b-b37c-603391f95539", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
					"NONE"),
			new VisualElement("TEXT", 23, 108, 218, 123, String.join("", new String[]{
					"[size=6]Do you have an idea for the mod?\n\nIf you would like to suggest new items, mechanics, or features for Deep Dark Binding, you can leave a comment on the mod's CurseForge page.\n\nYou can also join the developer's Discord server to share your suggestions, report bugs, or discuss future updates with the community.\n\nAll ideas are welcome and can help shape the evolution of the mod.[/size]"}),
					"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")})}),
			new Category("65cf72c8-afc5-493e-aebd-e5994b479238", "ores", new Page[]{new Page("5a6144e0-421a-4f14-b4ea-f014a8e4b3e3", "ores from the mod", true, new VisualElement[]{
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("TEXT", 8, 41, 239, 216, String.join("", new String[]{
							"[size=6]Deep Dark Binding adds five new ores to discover and mine:\n\n• **Aetherite**: An ore linked to the power of wind. It is used to craft items that harness this element.\n\n• **Venomite**: A toxic ore used in the creation of poison-related materials and items.\n\n• **Witherite**: A dark ore infused with the energy of the Wither.\n\n• **Pyrite**: A versatile ore used in the crafting of various tools, weapons, and items.\n\n• **Ignitite**: A fiery ore connected to heat and flames, used to craft fire-themed equipment and materials.\n\nEach ore has its own unique properties and uses, allowing players to unlock new possibilities throughout their adventure.\n[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("4e64e068-d40f-4204-8a61-36199d5cc883", "Aetherite ore", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 17, 49, 208, 143, String.join("", new String[]{
									"[size=6]**Aetherite** is a rare ore infused with the power of the wind.\n\nThis ore can be found between **Y -64 and Y 16**. Its **Deepslate Aetherite Ore** variant generates between **Y -64 and Y 0**.\n\nAetherite is used to craft items related to the air element and harness the power of the wind. Its light and mysterious nature sets it apart from ordinary ores.\n\nMining Aetherite is an important step for adventurers seeking to master the power of the wind.\n[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 94, 201, 70, 32, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_225910", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("547cc142-c9d3-46ea-86c7-b96f4a847f37", "venomite ore", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 17, 49, 208, 163, String.join("", new String[]{
									"[size=7]**Venomite** is a toxic ore infused with poisonous properties.\n\nThis ore can be found between **Y -16 and Y 64**. Its **Deepslate Venomite Ore** variant generates between **Y -48 and Y 0**.\n\nVenomite is used to craft items and materials related to poison. Its unique properties make it a valuable resource for adventurers seeking to harness toxic powers.\n\nMining Venomite is essential for unlocking new poison-based crafting possibilities.\n[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 89, 219, 74, 35, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_230003", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("08c6b140-07bc-4af0-83d7-db45e96865c0", "witherite ore", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 17, 48, 208, 160, String.join("", new String[]{
									"[size=6]**Witherite** is a dark and dangerous ore infused with the power of the Wither.\n\nThis ore can be found between **Y -64 and Y -32**. Its **Deepslate Witherite Ore** variant generates between **Y -64 and Y -48**.\n\nWitherite is used to craft items and materials connected to the destructive energy of the Wither. Its dark nature makes it one of the most mysterious resources in the mod.\n\nMining Witherite is a challenging task, but it rewards adventurers with access to unique crafting possibilities.\n[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 88, 217, 76, 34, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_230036", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("4b2b58a7-0308-4e3f-8673-f3ff04c298a7", "pyrite ore", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 19, 48, 208, 216, String.join("", new String[]{
									"[size=6]**Pyrite** is a fiery ore infused with the power of flames.\n\nThis ore can be found between **Y -32 and Y 48**. Its **Deepslate Pyrite Ore** variant generates between **Y -64 and Y 0**.\n\nPyrite is used to craft items and materials related to fire. Its intense heat and unique properties make it a valuable resource for adventurers seeking to harness the power of flames.\n\nMining Pyrite is an important step toward unlocking fire-based crafting possibilities.\n[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 85, 192, 80, 37, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_230113", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("efb2efa1-93a2-4249-9b90-f9c75dfbb514", "ignitite debris", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 225, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#FFF4D6", "#FFF4D6", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 18, 48, 208, 188, String.join("", new String[]{
									"[size=6]**Ignitite** is a rare ore found exclusively in the Nether. Comparable in value to Netherite, it is a powerful resource used to craft advanced equipment.\n\nWhen used to create armor, Ignitite grants its wearer **Fire Resistance**, allowing them to better survive the extreme heat of the Nether.\n\nIgnitite Ore generates in three Nether biomes:\n\n* **Nether Wastes**\n* **Crimson Forest**\n* **Basalt Deltas**\n\nIt can be found between **Y 8 and Y 64**.\n\nDue to its rarity and unique properties, Ignitite is one of the most valuable resources in Deep Dark Binding.\n[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 105, 245, 40, 40, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_230310", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")})}),
			new Category("b06d0a29-0d87-45b9-bc31-3cc8d76048ec", "tools", new Page[]{new Page("6c470c67-8a1d-4a7c-afdd-bed4c57f8beb", "Page 1", false, new VisualElement[]{
					new VisualElement("TEXT", 18, 48, 220, 220, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("TEXT", 20, 53, 208, 216, String.join("", new String[]{
							"[size=6] Tools\n\nIn this section, you will find all the tools added by **Deep Dark Binding**.\n\nThe mod adds several types of tools, ranging from equipment crafted using the different ores added by the mod to tools with unique functions. You will find classic ore-based tools, the **Hammer**, **Lassos**, and the different **Sun Bags**.\n\nEach tool has its own characteristics and uses. Some are designed to make mining and exploration easier, while others provide more specific functions.\n\nExplore the different pages in this section to discover how to craft each tool, as well as their characteristics and various uses.\n[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("8ca9b834-663a-4c13-b2bf-e5e422ce4a17", "sunbag", true, new VisualElement[]{
							new VisualElement("TEXT", 16, 48, 220, 220, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 17, 48, 208, 128, String.join("", new String[]{
									"[size=6]Sun Bag\n\nThe **Sun Bag** is a portable storage bag that works like a chest you can carry with you.\n\nThere are several **Sun Bag tiers**, each with a different storage capacity. The higher the tier, the more slots the Sun Bag has for storing your items.\n\nSun Bags are especially useful for adventures and exploration, as they allow you to carry and store a large number of items without having to return to your base.\n[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 35, 184, 180, 33, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-11_214124", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE"),
							new VisualElement("TEXT", 36, 183, 35, 35, String.join("", new String[]{"[size=8]T1    [/size]"}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 73, 183, 26, 32, String.join("", new String[]{"[size=8]T2 [/size]"}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 110, 183, 29, 19, String.join("", new String[]{"[size=8]T3[/size]"}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 145, 183, 25, 18, String.join("", new String[]{"[size=8]T4[/size]"}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 181, 183, 27, 28, String.join("", new String[]{"[size=8]T5[/size]"}), "LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("86345ddf-f494-4776-945b-b586d28017aa", "stick(tools)", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 15, 38, 212, 43, String.join("", new String[]{
									"[size=6]This category includes tool-type Staves. Unlike the mod's other Staves, which are primarily used as weapons, these offer utility capabilities to facilitate exploration, movement, and various interactions with the world.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 15, 83, 208, 110, String.join("", new String[]{
									"[size=6]Spider Staff\n\nThe Spider Staff allows you to spawn spider webs at a targeted location. It is useful for slowing down creatures, blocking passages, or setting traps.\n\nEnder Stick\n\nThe Ender Stick allows you to throw Ender Pearls. Upon impact, the player is teleported to the spot where the pearl landed, making movement and exploration easier.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 225, 161, 29, 29, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_225713", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE"),
							new VisualElement("IMAGE", 225, 101, 30, 30, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-17_225730", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("5e6e1599-c161-4092-b21f-1690c45aa440", "lasso", true, new VisualElement[]{
							new VisualElement("TEXT", 4, 40, 220, 55,
									String.join("", new String[]{"[size=6]Lassos\n\nLassos allow you to capture and transport creatures without having to move them manually. Each lasso is designed for a specific type of creature.[/size]"}), "LEFT",
									"", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 5, 100, 251, 187, String.join("", new String[]{
									"[size=6]Compatibility with other mods\n\nCurrently, the lassos can only capture standard Minecraft creatures and monsters; creatures added by other mods cannot be captured.\n\nThis limitation stems from how the lassos currently function, relying on predefined lists of compatible creatures.\n\nHowever, the creation of add-ons for the mod is permitted. Developers wishing to add compatibility for creatures from other mods can create their own extensions to add these entities to the lasso lists.\n\nTo obtain the mod's development files, visit the Deep Dark Binding CurseForge page and click the GitHub link found in the project's links section.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("ae0cd445-a13b-46a3-8ed7-12dedb3770d6", "golden lasso", true, new VisualElement[]{new VisualElement("TEXT", 10, 43, 236, 135, String.join("", new String[]{
							"[size=6]Golden Lasso\n\nThe Golden Lasso allows you to capture passive creatures, such as cows, sheep, pigs, and other peaceful animals. Once captured, the creature can be released wherever you choose.\n\nPlease note: the Golden Lasso is still under development and has certain limitations. Captured creatures do not retain their custom names (Name Tags). Additionally, the inventories of creatures capable of carrying items—such as horses or mules—are not currently preserved. Finally, it is recommended to avoid capturing creatures with specific variants, as they may revert to their default form upon release.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 103, 192, 43, 43, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-18_200814", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("771f82ee-3ed0-4318-aff2-0ddc9f22e96a", "dark lasso", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 122, String.join("", new String[]{
							"[size=6]Dark Lasso\n\nThe Dark Lasso allows you to capture hostile creatures and monsters. It is particularly useful for moving monsters to a monster farm or transporting them to a specific area before releasing them.\n\nNote: The Dark Lasso can capture most monsters in the game. However, boss-type creatures—such as the Wither, Ender Dragon, or Elder Guardian—cannot be captured. The Warden is an exception to this rule and can be captured using the Dark Lasso.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 107, 183, 42, 44, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-09-18_200857", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("d1fe1ebc-5f28-4ee3-b3db-02dcdba78c65", "pyrite pickaxe", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 169, String.join("", new String[]{
							"[size=7]# Pyrite Pickaxe\n\nThe **Pyrite Pickaxe** is a tool crafted from Pyrite ore.\n\nIts special ability allows it to **automatically smelt certain mined blocks**. When a block is broken with this pickaxe, it drops the smelted result directly instead of its usual resource.\n\nFor example, iron ore will drop **smelted raw iron** directly, without requiring the use of a furnace.\n\nThis ability saves time and reduces fuel consumption during mining sessions.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 104, 251, 44, 38, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_185504", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")})}),
			new Category("0a6c820d-597d-4933-8ca9-53deff927517", "dynamite", new Page[]{new Page("8f21ff39-1d02-4de3-925d-7aef8bffa6b4", "dynamite", true, new VisualElement[]{
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("TEXT", 0, 34, 256, 240, String.join("", new String[]{
							"[size=6]# Les Dynamites\n\nDeep Dark Binding adds **15 types of dynamite**, each with a unique \neffect.\n\nAll the dynamite sticks are crafted from standard TNT combined with various materials to produce special effects.\n\nUnlike ordinary TNT, these sticks do more than just cause an explosion. Each one possesses distinct properties that can be utilized for combat, exploration, mining, or other situations.\n\nDiscover and experiment with the different types of dynamite to find the ones that best suit your playstyle..\n[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("86927f8b-383d-4de1-b475-6aab9e5f40c2", "dynamite tier", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 1, 34, 251, 239, String.join("", new String[]{
									"[size=6]# Power Dynamites\n\nPower dynamites are classified into **5 tiers**, ranging from **Classic Dynamite (T1)** to **T5 Dynamite**.\n\nEach tier has twice the explosive power of the preceding tier:\n\n* Classic Dynamite (T1): Power 8\n* T2 Dynamite: Power 16\n* T3 Dynamite: Power 32\n* T4 Dynamite: Power 64\n* T5 Dynamite: Power 128\n\nThanks to their increasing power, these dynamites are particularly well-suited for mining large areas or rapidly destroying obstacles.\n\nWarning: higher tiers can cause significant damage to the environment and to entities located near the explosion.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("7bb63071-5ae5-4db5-bfd3-c2f14d042c22", "dynamite effect", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 3, 36, 248, 233, String.join("", new String[]{
									"[size=6]# Effect Dynamites\n\nEffect Dynamites are special explosives that, in addition to the explosion itself, release a **lingering potion cloud** at the detonation site.\n\nEntities passing through this cloud will be affected by the specific effect associated with the dynamite used.\n\nThe available effects are:\n\n* Poison\n* Wither\n* Weakness\n* Wind Charge\n* Blindness\n* Nausea\n* Slowness\n\nThese dynamites are particularly useful for area control, weakening groups of enemies, or preparing for a fight before opponents arrive.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("d64c2570-803d-4869-8d1f-f6ce08602c16", "spéciale dynamite", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 0, 35, 251, 237, String.join("", new String[]{
									"[size=6]# Special Dynamites\nDeep Dark Binding also adds **3 special dynamites** with unique effects.\n\n## Dragon Dynamite\nDragon Dynamite summons a **dragon fireball** upon exploding. This dynamite is ideal for dealing extra damage and wreaking havoc on the battlefield.\n\n## Nuke Dynamite\nNuke Dynamite is **exclusive to Creative Mode**.\nIts explosion is extremely powerful and can cause significant performance drops or even lag for nearby players. For this reason, it is not intended for use in Survival Mode.\n\n## XP Dynamite\nXP Dynamite is also **exclusive to Creative Mode**.\nThis dynamite was added primarily for fun. Its effect is linked to experience points, allowing for unique explosions centered around XP orbs.\n\nNote: Some special dynamites can significantly impact game performance. It is recommended to use them with caution.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")})}),
			new Category("c54d0643-e58f-4d34-80b6-048f20722843", "armors", new Page[]{new Page("c2577516-73c5-4baf-b5c4-2d772141f5be", "armors", true, new VisualElement[]{new VisualElement("TEXT", 10, 46, 232, 220, String.join("", new String[]{
					"[size=6][size=6]# Armor Sets\r\nDeep Dark Binding adds **5 new armor sets** for you to discover and craft during your adventure:\r\n\r\n* Aetherite Armor\r\n\r\n* Witherite Armor\r\n\r\n* Venomite Armor\r\n\r\n* Pyrite Armor\r\n\r\n* Ignitite Armor\r\n\r\nEach armor set has its own unique characteristics and offers new possibilities for upgrading your gear and facing the dangers of the world[/size]"}),
					"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")}),
					new Page("c28b0b87-4294-4f04-ad89-90ab8f218451", "aetherite armor", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 7, 40, 248, 209, String.join("", new String[]{
									"[size=6]# Aetherite Armor\n\nAetherite armor is crafted from Aetherite ore.\n\nThe complete set includes:\n\n* Aetherite Helmet\n* Aetherite Chestplate\n* Aetherite Leggings\n* Aetherite Boots\n\nCertain pieces of the armor provide effects when worn:\n\n* **Aetherite Helmet**: Night Vision\n* **Aetherite Leggings**: Jump Boost\n\nThis armor is an excellent choice for exploration, allowing for better visibility in the dark and easier movement through challenging environments.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 59, 248, 151, 36, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_185617", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("406ee710-c3c2-46e0-8c34-6285c96235f0", "witherite armor", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 5, 37, 246, 238, String.join("", new String[]{
									"[size=6]# Witherite Armor\n\nWitherite armor is crafted from Witherite ore.\n\nThe full set includes:\n\n* Witherite Helmet\n* Witherite Chestplate\n* Witherite Leggings\n* Witherite Boots\n\nWhen the full armor set is worn, hostile entities or players that deal damage to the wearer are afflicted with the **Wither** effect for a short duration.\n\nThis ability punishes attackers and gradually drains their health during combat.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 37, 239, 115, 31, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_185817", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE"),
							new VisualElement("IMAGE", 154, 239, 35, 29, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_185825", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("653e5fca-c7c5-45e6-b11b-7f4de12f1748", "venomite armor", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 1, 36, 249, 175, String.join("", new String[]{
									"[size=6]# Venomite Armor\n\nVenomite armor is crafted from Venomite ore.\n\nThe full set includes:\n\n* Venomite Helmet\n* Venomite Chestplate\n* Venomite Leggings\n* Venomite Boots\n\nWhen the full armor set is worn, hostile entities or players that deal damage to the wearer are afflicted with the **Poison** effect for a short duration.\n\nThis ability allows the wearer to gradually weaken attackers during combat.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 51, 258, 146, 29, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_185931", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("6490deef-210f-46da-a271-65736f315138", "pyrite armor", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 1, 35, 252, 165, String.join("", new String[]{
									"[size=6]# Pyrite Armor\n\nPyrite armor is crafted from Pyrite ore.\n\nThe complete set includes:\n\n* Pyrite Helmet\n* Pyrite Chestplate\n* Pyrite Leggings\n* Pyrite Boots\n\nWhen the full armor set is worn, hostile entities or players that deal damage to the wearer are **set ablaze** for a short duration.\n\nThis ability deals extra damage to attackers and discourages them from engaging in melee combat.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 64, 252, 136, 25, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190038", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("df8246e5-7902-4863-96ab-b7e5b684b626", "ignitite armor", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 2, 34, 254, 241, String.join("", new String[]{
									"[size=6]# Ignitite Armor\n\nIgnitite armor is crafted from Ignitite ore. It is considered a superior version of Netherite armor.\n\nThe full set includes:\n\n* Ignitite Helmet\n* Ignitite Chestplate\n* Ignitite Leggings\n* Ignitite Boots\n\nTo craft a piece of Ignitite armor, follow the same process used to upgrade Diamond armor to Netherite armor. Use a Smithing Table to upgrade your Netherite gear using the necessary materials.\n\nWhen the full armor set is worn, the player permanently benefits from the Fire Resistance effect.\n\nThis ability makes Ignitite armor particularly well-suited for exploring the Nether, allowing the player to traverse lava lakes without taking damage. It is also an excellent choice for combat involving fire-based attacks or hazardous environments.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 123, 95, 64, 27, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190124", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE"),
							new VisualElement("IMAGE", 189, 96, 61, 26, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190129", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")})}),
			new Category("1bedde13-2227-4d2e-97a8-f0d987a73e88", "swords", new Page[]{new Page("b9d5f0d4-ec59-4e4e-a7df-170e7a578209", "aetherite sword", true, new VisualElement[]{
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("TEXT", 0, 35, 256, 102, String.join("", new String[]{
							"[size=6]# Aetherite Sword\n\nThe Aetherite sword is crafted from Aetherite ore.\n\nWhen an entity is struck with this weapon, it is afflicted with the Weakness effect for a short duration. This effect reduces the damage the entity deals, allowing the player to gain the upper hand in combat.\n\nThe Aetherite sword is particularly effective against powerful enemies, as it diminishes their ability to deal damage to the player.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
					new VisualElement("IMAGE", 110, 168, 38, 39, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190243", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
							"NONE")}),
					new Page("1a63b644-0160-440a-8dd0-d10620b0a3cb", "pyrite sword", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 2, 34, 248, 141, String.join("", new String[]{
									"[size=6]# Pyrite Sword\n\nThe Pyrite Sword is crafted from Pyrite ore.\n\nWhen an entity is struck by this weapon, it is set ablaze for a short time and takes fire damage.\n\nThanks to this ability, the Pyrite Sword provides an effect similar to the Fire Aspect enchantment without needing to apply it to the weapon. This reduces the **experience** and lapis lazuli costs required to enchant your gear.\n\nThis sword is particularly effective against enemies vulnerable to fire damage.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 107, 225, 43, 34, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190307", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("c95f2b24-d7e8-49d9-a07d-4d9948f0bd75", "witherite sword", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 2, 35, 254, 143, String.join("", new String[]{
									"[size=6]# Witherite Sword\n\nThe Witherite sword is crafted from Witherite ore.\n\nWhen an entity is struck with this weapon, it is afflicted with the Wither effect for a short duration. This effect deals damage over time and gradually reduces the target's health.\n\nThanks to this ability, the Witherite sword continues to weaken enemies even after the initial strike, making it a formidable weapon in prolonged battles.\n\nThis sword is particularly effective against opponents with large amounts of health.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 112, 238, 36, 35, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190259_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("3132760f-9a30-4fb0-ac03-370ea79d566c", "venomite sword", true, new VisualElement[]{
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("TEXT", 3, 38, 251, 144, String.join("", new String[]{
									"[size=6]# Venomite Sword\n\nThe Venomite sword is crafted from Venomite ore.\n\nWhen an entity is struck with this weapon, it is afflicted with the Poison effect for a short duration. This effect deals damage over time and weakens the target.\n\nThanks to this ability, the Venomite sword continues to wear down opponents even after the initial strike, making it particularly effective against resilient enemies.\n\nThis weapon is ideal for players who favor damage-over-time effects.[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 105, 239, 47, 42, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190253_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")})}),
			new Category("79dba7d7-9aa6-435b-b37c-603391f95539", "mining dimension", new Page[]{
					new Page("6c1f0a79-eba2-4ba3-bf34-93fb0e730a1e", "mining dimension", true, new VisualElement[]{new VisualElement("TEXT", 10, 45, 238, 220, String.join("", new String[]{
							"[size=6][size=6][size=6][size=6][size=6]# Mining Dimension\r\nThe Mining Dimension is a world specifically designed for resource extraction. Its purpose is to allow players to gather ores and materials without having to scour the Overworld in search of caves or unexplored areas.\r\n\r\nThis dimension is ideal for long mining sessions and helps preserve the landscapes of your main world. You can dig freely, explore caverns, and collect the resources needed for your progression.\r\n\r\nIf you are looking for ores in large quantities, the Mining Dimension will quickly become an essential part of your adventure.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")}),
					new Page("58b4f536-21e1-44f5-b695-0fb1d91fb994", "dimension portal", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 122, String.join("", new String[]{
							"[size=6][size=6][size=6][size=6]# Mining Dimension Portal\r\r\r\r\r\r\n\r\r\r\r\r\r\nTo access the Mining Dimension, you must build a portal similar to a Nether portal. However, instead of using obsidian, the frame must be made entirely of **Portal Frames**.\r\r\r\r\r\r\n\r\r\r\r\r\r\nOnce the structure is complete, equip a **Mining Brush** and right-click the inside of the portal. It will then activate and open a passage to the Mining Dimension.\r\r\r\r\r\r\n\r\r\r\r\r\r\nThe Portal Frame looks similar to obsidian, making it easy to distinguish while maintaining a familiar style[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 62, 228, 141, 77, String.join("", new String[]{""}), "LEFT", "capture_d_cran_29", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("881401bc-0db3-45af-b572-92e270a33dea", "dimension biome", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 229, 125, String.join("", new String[]{
							"[size=6][size=6][size=6][size=6]# Mining Dimension Biomes\r\r\r\r\r\r\n\r\r\r\r\r\r\nThe Mining Dimension features a total of **5 different biomes**:\r\r\r\r\r\r\n\r\r\r\r\r\r\n* Deep Dark\r\r\r\r\r\r\n* Dripstone Caves\r\r\r\r\r\r\n* Lush Cave\r\r\r\r\r\r\n* Deep Mining\r\r\r\r\r\r\n* Stone Peak\r\r\r\r\r\r\n\r\r\r\r\r\r\nThese biomes offer diverse environments for your mining and exploration [/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")})}),
			new Category("c8539360-3438-4596-8698-5b6c42f5738d", "plant", new Page[]{new Page("cf07291d-c296-47d4-bbe2-fe19a8c8a826", "hellfire bloom", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 86, String.join("", new String[]{
					"[size=6]The **Hellfire Bloom** is a plant native to the Nether. This strange flower thrives in the most hostile environments and draws its energy from the heat of the infernal depths.\n\n Once fully grown, the Hellfire Bloom can be harvested to yield **Blaze Rods**. It thus serves as a renewable source of this resource, eliminating the need to hunt Blazes in Nether fortresses.[/size]"}),
					"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("IMAGE", 36, 155, 180, 103, String.join("", new String[]{""}), "LEFT", "capture_d_cran_9", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("53820aef-09e5-471a-9fe8-c762c7994e44", "end orchid", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 72, String.join("", new String[]{
							"[size=6]The End Orchid is a plant native to the End. This strange flower has adapted to the dimension's mysterious environment and draws its energy from the forces of the End.\n\nOnce fully grown, the End Orchid can be harvested to yield Ender Pearls, providing a renewable source of this resource without the need to hunt Endermen.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 35, 141, 180, 101, String.join("", new String[]{""}), "LEFT", "capture_d_cran_10", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")})}),
			new Category("908cc752-c09a-4f32-afb7-42dd908564bf", "artefact", new Page[]{new Page("0fb88f5d-3540-477a-8126-70fb411b8639", "ring", true, new VisualElement[]{
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("TEXT", 2, 36, 249, 236, String.join("", new String[]{
							"[size=7]# Rings\n\nRings are special artifacts that grant various bonuses to the wearer.\n\nEach Ring has a unique effect that can enhance the player's abilities, facilitate exploration, or provide advantages in combat.\n\nA player can equip only **3 Rings at a time**. It is therefore important to choose the artifacts best suited to your situation and playstyle.\n\nEquip the Ring of your choice to harness its powers and tailor your loadout to your needs.\n\nMany Rings are available in Deep Dark Binding, each offering its own unique effects and benefits.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("97f2523b-53d3-40b7-82a7-d1c38433c541", "ring of vitality", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 115, String.join("", new String[]{
							"[size=6]# Ring of Vitality\n\nThe **Ring of Vitality** is an artifact that grants its wearer a permanent **Regeneration** effect.\n\nWhile the ring is equipped, the player benefits from continuous health regeneration, making survival easier during exploration and combat.\n\nAs with all effects granted by rings, the potency of the effect is intentionally limited to maintain game balance.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 106, 212, 52, 50, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190800", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("4658efbd-edb3-43cf-a622-8ff572f832b4", "ring of mining", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 231, 90, String.join("", new String[]{
							"[size=6]# Ring of Mining\n\nThe **Ring of Mining** is an artifact that grants its wearer the **Haste** effect permanently.\n\nWhile the ring is equipped, the player benefits from increased mining speed, allowing them to break blocks faster and improve their efficiency when gathering resources.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 101, 176, 52, 54, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190828", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("c4786a4c-1842-4820-bb56-1d6800ff0791", "ring of speed", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 87, String.join("", new String[]{
							"[size=6]# Ring of Speed\n\nThe **Ring of Speed** is an artifact that grants its wearer the **Speed** effect permanently.\n\nWhile the ring is equipped, the player benefits from increased movement speed, allowing them to move faster during exploration and combat.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 104, 166, 46, 45, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190901", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("aebddea2-a9a7-4532-831e-52454089be94", "ring of hunter", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 90, String.join("", new String[]{
							"[size=6]# Ring of Hunter\n\nThe **Ring of Hunter** is an artifact that grants its wearer the **Night Vision** effect permanently.\n\nAs long as the ring is equipped, the player can see clearly in the dark, making it easier to explore caves, mines, and other dimly lit environments.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 92, 171, 58, 62, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_190939", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("3de8dcd2-67e3-4b58-83a5-fcd9c7f55784", "ring of invisibility", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 85, String.join("", new String[]{
							"[size=6]# Ring of Invisibility\n\nThe **Ring of Invisibility** is an artifact that grants its wearer the **Invisibility** effect permanently.\n\nAs long as the ring is equipped, the player becomes invisible, allowing them to move more stealthily and more easily avoid certain threats.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 95, 169, 57, 61, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_191019", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("1be90f77-1b9c-4ed7-90b4-80f19d3fbb39", "ring of water", true, new VisualElement[]{new VisualElement("TEXT", 9, 40, 238, 114, String.join("", new String[]{
							"[size=6]# Ring of Water\n\nThe Ring of Water is an artifact that grants its wearer the **Water Breathing** effect permanently.\n\nAs long as the ring is equipped, the player can remain underwater without running out of air, making it easier to explore oceans, rivers, and underwater structures.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 96, 175, 51, 54, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_191106", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("d6ebfe2a-0370-44d3-8362-352a6b82958f", "amullette", true, new VisualElement[]{new VisualElement("TEXT", 1, 38, 251, 109, String.join("", new String[]{
							"[size=6]# Amulets\n\nDeep Dark Binding adds **3 amulets** that grant special abilities to the wearer.\n\nUnlike rings, a player can only equip **2 amulets at a time**. It is therefore necessary to choose the amulets best suited to the situation.\n\nEach amulet has its own unique effect and can provide additional protection or an advantage during exploration and combat.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")}),
					new Page("1d99254f-f8c7-4f37-9513-40dd279c38f3", "amulette of purity", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 81, String.join("", new String[]{
							"[size=6]# Amulet of Purity\n\nThe **Amulet of Purity** protects its wearer against the poison effect.\n\nWhile the amulet is equipped, the player is immune to the poison effect and takes no damage from this status ailment.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 92, 162, 62, 63, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_191131", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("cbd421f0-94c7-42b0-a81a-6587d10bc7ef", "amulette of sacred light", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 85, String.join("", new String[]{
							"[size=6]# Amulet of Sacred Light\n\nThe **Amulet of Sacred Light** grants its wearer resistance to the effects of **Wither**.\n\nWhile the amulet is equipped, the effects of Wither are less dangerous to the player, allowing them to better survive against enemies and environments that utilize this status effect.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 99, 157, 50, 44, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_191201", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("efae87df-6e51-4081-9782-cfaa59583ef9", "piglin lord amulette", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 114, String.join("", new String[]{
							"[size=6]# Piglin Lord Amulet\n\nThe **Piglin Lord Amulet** is an amulet that prevents Piglins from becoming hostile toward the wearer.\n\nWhile the amulet is equipped, Piglins behave as if the player were wearing a gold helmet.\n\nNote that the same rules apply as with a gold helmet: certain actions—such as opening chests or mining gold blocks near Piglins—can still provoke them.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 96, 189, 53, 48, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_191225", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")}),
					new Page("d3e861e0-8592-4453-bfdb-785fe056ea0b", "alpha horn", true, new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 118, String.join("", new String[]{
							"[size=6]# Alpha Horn\n\nThe **Alpha Horn** is an artifact used to summon temporary allies.\n\nWhen the player blows into the horn, **3 tamed wolves** appear to fight alongside them. These wolves attack the player's enemies and assist them during combat.\n\nHowever, the summoned wolves are not permanent and will disappear after a certain amount of time.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 95, 199, 59, 53, String.join("", new String[]{""}), "LEFT", "capture_d_cran_2026-10-05_191305", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
									"NONE")})}),
			new Category("7b215a55-ecda-498b-9bd4-8e8d3f2ee666", "block", new Page[]{new Page("b51c83a9-c601-48d2-aa41-101074a65ef5", "spike", true, new VisualElement[]{
					new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
					new VisualElement("TEXT", 9, 37, 237, 238, String.join("", new String[]{
							"[size=6]# Spikes\n\n**Spikes** are defensive blocks that deal damage to entities and players who walk on them.\n\nThey can be crafted from various materials. The damage dealt depends on the material used: the stronger and more valuable the material, the more dangerous the spikes are.\n\nSpikes are ideal for protecting a base, securing an area, or creating traps to use against hostile creatures and other players.[/size]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")})})};
	private final List<ClickRegion> clickRegions = new ArrayList<>();
	private int categoryIndex = 0;
	private int pageIndex = 0;
	private int categoryListPage = 0;
	private float uiScale = 1f;
	private int originX = 0;
	private int originY = 0;

	public Guidebookv2BookScreen() {
		super(Component.literal("guide book"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	/**
	 * Vanilla 1.21.1 applies the in-game menu blur from Screen#renderBackground.
	 * This book is an overlay, so keep only a translucent darkening layer.
	 */
	@Override
	public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		graphics.fill(0, 0, width, height, 0xB0100D0B);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		renderBackground(graphics, mouseX, mouseY, partialTick);
		clickRegions.clear();
		updateLayout();
		int startX = PAD;
		int pageX = PAD + SIDEBAR_W + GAP_W;
		int pageY = PAD;
		int sideY = PAD;
		fillD(graphics, startX, sideY, startX + SIDEBAR_W, sideY + PAGE_H, 0xEE28231F);
		fillD(graphics, startX + 5, sideY + 5, startX + SIDEBAR_W - 5, sideY + PAGE_H - 5, 0xFF342D27);
		fillD(graphics, pageX - 3, pageY - 3, pageX + PAGE_W + 3, pageY + PAGE_H + 3, 0xFF6C5033);
		fillD(graphics, pageX, pageY, pageX + PAGE_W, pageY + PAGE_H, 0xFFFFF4D6);
		drawCenteredD(graphics, Component.literal("guide book"), startX + SIDEBAR_W / 2, sideY + 16, 0xFFFFE5B8);
		renderCategories(graphics, startX + 13, sideY + 42, SIDEBAR_W - 26);
		Page page = currentPage();
		if (page == null) {
			drawCenteredD(graphics, Component.literal("No pages"), pageX + PAGE_W / 2, pageY + 32, 0xFF4B3929);
			return;
		}
		if (page.showTitle) {
			drawCenteredD(graphics, Component.literal(page.title), pageX + PAGE_W / 2, pageY + 17, 0xFF38291E);
			fillD(graphics, pageX + 14, pageY + 33, pageX + PAGE_W - 14, pageY + 34, 0xFFDDCDAA);
		}
		for (VisualElement element : page.elements)
			renderElement(graphics, element, pageX, pageY);
		renderNavigation(graphics, pageX, pageY);
	}

	/**
	 * The page is never scaled as one big texture/matrix. Every coordinate is transformed
	 * individually to an integer GUI coordinate. This avoids bilinear-looking blur at GUI
	 * scales 3-5 while still fitting the entire book on screen.
	 */
	private void updateLayout() {
		float availableW = Math.max(1f, width - 6f);
		float availableH = Math.max(1f, height - 6f);
		uiScale = Math.max(0.05f, Math.min(1f, Math.min(availableW / DESIGN_W, availableH / DESIGN_H)));
		originX = Math.max(3, Math.round((width - DESIGN_W * uiScale) / 2f));
		originY = Math.max(3, Math.round((height - DESIGN_H * uiScale) / 2f));
	}

	private int sx(int designX) {
		return originX + Math.round(designX * uiScale);
	}

	private int sy(int designY) {
		return originY + Math.round(designY * uiScale);
	}

	private int sd(int designSize) {
		return Math.max(1, Math.round(designSize * uiScale));
	}

	private void fillD(GuiGraphics graphics, int x1, int y1, int x2, int y2, int color) {
		graphics.fill(sx(x1), sy(y1), sx(x2), sy(y2), color);
	}

	private float crispTextScale(float requested) {
		double guiScale = Math.max(1.0, Minecraft.getInstance().getWindow().getGuiScale());
		int physicalScale = Math.max(1, (int) Math.round(Math.max(0.05f, requested) * guiScale));
		return (float) (physicalScale / guiScale);
	}

	private void drawTextD(GuiGraphics graphics, Component text, int x, int y, int color) {
		float scale = crispTextScale(uiScale);
		PoseStack pose = graphics.pose();
		pose.pushPose();
		pose.translate(sx(x), sy(y), 0);
		pose.scale(scale, scale, 1f);
		graphics.drawString(font, text, 0, 0, color, false);
		pose.popPose();
	}

	private void drawCenteredD(GuiGraphics graphics, Component text, int centerX, int y, int color) {
		float scale = crispTextScale(uiScale);
		PoseStack pose = graphics.pose();
		pose.pushPose();
		pose.translate(sx(centerX), sy(y), 0);
		pose.scale(scale, scale, 1f);
		graphics.drawString(font, text, -font.width(text) / 2, 0, color, false);
		pose.popPose();
	}

	private void addClickRegion(int x, int y, int w, int h, String type, String target) {
		int rx = sx(x);
		int ry = sy(y);
		int rw = Math.max(1, sx(x + w) - rx);
		int rh = Math.max(1, sy(y + h) - ry);
		clickRegions.add(new ClickRegion(rx, ry, rw, rh, type, target));
	}

	private void addScreenClickRegion(int x, int y, int w, int h, String type, String target) {
		clickRegions.add(new ClickRegion(x, y, Math.max(1, w), Math.max(1, h), type, target));
	}

	private void enableDesignScissor(GuiGraphics graphics, int x, int y, int w, int h) {
		int x1 = sx(x);
		int y1 = sy(y);
		int x2 = sx(x + w);
		int y2 = sy(y + h);
		graphics.enableScissor(x1, y1, Math.max(x1 + 1, x2), Math.max(y1 + 1, y2));
	}

	private void renderCategories(GuiGraphics graphics, int x, int y, int w) {
		int pageCount = Math.max(1, (CATEGORIES.length + CATEGORY_ROWS - 1) / CATEGORY_ROWS);
		categoryListPage = Math.max(0, Math.min(categoryListPage, pageCount - 1));
		int first = categoryListPage * CATEGORY_ROWS;
		int cy = y;
		for (int i = first; i < Math.min(CATEGORIES.length, first + CATEGORY_ROWS); i++) {
			Category category = CATEGORIES[i];
			boolean selected = i == categoryIndex;
			fillD(graphics, x - 4, cy - 4, x + w + 4, cy + 15, selected ? 0xFF5C4A3A : 0x00101010);
			drawTextD(graphics, Component.literal(category.name), x, cy, selected ? 0xFFFFE8B8 : 0xFFD7C4A5);
			addClickRegion(x - 4, cy - 4, w + 8, 19, "category", category.id);
			cy += 23;
		}
		if (pageCount > 1) {
			int pagerY = y + CATEGORY_ROWS * 23 + 3;
			if (categoryListPage > 0) {
				drawCenteredD(graphics, Component.literal("<"), x + 8, pagerY + 3, 0xFFFFE8B8);
				addClickRegion(x - 4, pagerY, 26, 18, "category_list", "prev");
			}
			drawCenteredD(graphics, Component.literal((categoryListPage + 1) + " / " + pageCount), x + w / 2, pagerY + 3, 0xFFD7C4A5);
			if (categoryListPage + 1 < pageCount) {
				drawCenteredD(graphics, Component.literal(">"), x + w - 8, pagerY + 3, 0xFFFFE8B8);
				addClickRegion(x + w - 22, pagerY, 26, 18, "category_list", "next");
			}
		}
	}

	private void changeCategoryListPage(int delta) {
		int pageCount = Math.max(1, (CATEGORIES.length + CATEGORY_ROWS - 1) / CATEGORY_ROWS);
		categoryListPage = Math.max(0, Math.min(categoryListPage + delta, pageCount - 1));
	}

	private void renderElement(GuiGraphics graphics, VisualElement element, int pageX, int pageY) {
		int x = pageX + element.x;
		int y = pageY + element.y;
		int w = Math.max(1, element.width);
		int h = Math.max(1, element.height);
		switch (element.type) {
			case "TEXT" -> {
				enableDesignScissor(graphics, x, y, w, h);
				renderRichTextBlock(graphics, element.content, x, y, w, h, element.align);
				graphics.disableScissor();
			}
			case "IMAGE" -> renderImage(graphics, element.mediaName, x, y, w, h);
			case "GIF" -> renderImage(graphics, currentFrame(element), x, y, w, h);
			case "BUTTON" -> {
				renderButton(graphics, element, x, y, w, h);
				addClickRegion(x, y, w, h, element.targetPageId.isBlank() ? "category" : "page", element.targetPageId.isBlank() ? element.targetCategoryId : element.targetPageId);
			}
			case "NAV_PREV" -> {
				if (canAdvance(-1)) {
					renderNavigationArrow(graphics, element, x, y, w, h, false);
					addClickRegion(x, y, w, h, "nav", "prev");
				}
			}
			case "NAV_NEXT" -> {
				if (canAdvance(1)) {
					renderNavigationArrow(graphics, element, x, y, w, h, true);
					addClickRegion(x, y, w, h, "nav", "next");
				}
			}
		}
	}

	private void renderButton(GuiGraphics graphics, VisualElement element, int x, int y, int w, int h) {
		int bg = parseHexColor(element.buttonBackgroundColor, 0xFF8A6846);
		int border = parseHexColor(element.buttonBorderColor, 0xFF6D5237);
		int textColor = parseHexColor(element.buttonTextColor, 0xFFFFEDC5);
		boolean hasImage = element.buttonImageName != null && !element.buttonImageName.isBlank();
		boolean backgroundImage = hasImage && ("BACKGROUND".equals(element.buttonImageMode) || "IMAGE".equals(element.buttonStyle));
		if (backgroundImage)
			renderResourceImage(graphics, element.buttonImageName, element.buttonImageType, x, y, w, h);
		switch (element.buttonStyle) {
			case "FLAT" -> {
				if (!backgroundImage)
					fillD(graphics, x, y, x + w, y + h, bg);
				drawButtonBorder(graphics, x, y, w, h, border, 1);
			}
			case "OUTLINE" -> drawButtonBorder(graphics, x, y, w, h, border, 2);
			case "TRANSPARENT" -> {
			}
			case "IMAGE" -> {
				if (!backgroundImage)
					fillD(graphics, x, y, x + w, y + h, bg);
				drawButtonBorder(graphics, x, y, w, h, border, 1);
			}
			default -> {
				if (!backgroundImage) {
					fillD(graphics, x, y, x + w, y + h, border);
					if (w > 4 && h > 4)
						fillD(graphics, x + 2, y + 2, x + w - 2, y + h - 2, bg);
				} else {
					drawButtonBorder(graphics, x, y, w, h, border, 1);
				}
			}
		}
		int textLeft = x + 4;
		int textRight = x + w - 4;
		if (hasImage && "ICON_LEFT".equals(element.buttonImageMode)) {
			int icon = Math.max(4, Math.min(h - 6, Math.min(24, w / 3)));
			int iy = y + Math.max(2, (h - icon) / 2);
			renderResourceImage(graphics, element.buttonImageName, element.buttonImageType, x + 4, iy, icon, icon);
			textLeft += icon + 4;
		}
		Component label = Component.literal(element.label == null ? "Button" : element.label);
		int available = Math.max(1, textRight - textLeft);
		float labelScale = crispTextScale(uiScale);
		int logicalLabelWidth = Math.max(1, Math.round(font.width(label) * labelScale / Math.max(0.05f, uiScale)));
		int center = textLeft + available / 2;
		if (logicalLabelWidth > available)
			center = textLeft + logicalLabelWidth / 2;
		drawCenteredD(graphics, label, center, y + Math.max(2, (h - 9) / 2), textColor);
	}

	private void drawButtonBorder(GuiGraphics graphics, int x, int y, int w, int h, int color, int thickness) {
		for (int i = 0; i < thickness; i++) {
			fillD(graphics, x + i, y + i, x + w - i, y + i + 1, color);
			fillD(graphics, x + i, y + h - i - 1, x + w - i, y + h - i, color);
			fillD(graphics, x + i, y + i, x + i + 1, y + h - i, color);
			fillD(graphics, x + w - i - 1, y + i, x + w - i, y + h - i, color);
		}
	}

	private static int parseHexColor(String value, int fallback) {
		try {
			if (value != null && value.matches("#[0-9a-fA-F]{6}"))
				return 0xFF000000 | Integer.parseInt(value.substring(1), 16);
		} catch (Exception ignored) {
		}
		return fallback;
	}

	private void renderImage(GuiGraphics graphics, String name, int x, int y, int w, int h) {
		renderResourceImage(graphics, name, "SCREEN", x, y, w, h);
	}

	private String currentFrame(VisualElement element) {
		if (element.frames.length == 0)
			return "";
		long frame = System.currentTimeMillis() / Math.max(20, element.frameDelay);
		return element.frames[(int) (frame % element.frames.length)];
	}

	private static String textureResource(String name, String typeName) {
		if (name == null || name.isBlank())
			return null;
		String namespace = "deep_dark_binding";
		String pathName = name.trim().replace('\\', '/');
		int colon = pathName.indexOf(':');
		if (colon >= 0) {
			namespace = pathName.substring(0, colon);
			pathName = pathName.substring(colon + 1);
		}
		if (pathName.isBlank() || pathName.startsWith("/"))
			return null;
		String folder = switch (typeName == null ? "SCREEN" : typeName) {
			case "ITEM" -> "item";
			case "BLOCK" -> "block";
			default -> "screens";
		};
		if (!pathName.startsWith("textures/")) {
			if (pathName.startsWith("item/") || pathName.startsWith("block/") || pathName.startsWith("screens/")) {
				pathName = "textures/" + pathName;
			} else {
				pathName = "textures/" + folder + "/" + pathName;
			}
		}
		if (!pathName.endsWith(".png"))
			pathName += ".png";
		if (!namespace.matches("[a-z0-9_.-]+") || !pathName.matches("[a-z0-9/._-]+"))
			return null;
		for (String segment : pathName.split("/", -1)) {
			if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment))
				return null;
		}
		return namespace + ":" + pathName;
	}

	private void renderResourceImage(GuiGraphics graphics, String name, String typeName, int x, int y, int w, int h) {
		String resource = textureResource(name, typeName);
		if (resource == null)
			return;
		int colon = resource.indexOf(':');
		ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(resource.substring(0, colon), resource.substring(colon + 1));
		int rx = sx(x);
		int ry = sy(y);
		int rw = Math.max(1, sx(x + w) - rx);
		int rh = Math.max(1, sy(y + h) - ry);
		graphics.blit(texture, rx, ry, 0, 0, rw, rh, rw, rh);
	}

	private void renderNavigation(GuiGraphics graphics, int pageX, int pageY) {
		Page page = currentPage();
		if (page != null) {
			// Compatibility fallback for books saved before v2.5.0. Once the element is
			// re-saved in MCreator, NAV_PREV / NAV_NEXT become normal configurable elements.
			if (canAdvance(-1) && !hasNavigationElement(page, "NAV_PREV")) {
				VisualElement fallback = defaultNavigationElement(false);
				renderNavigationArrow(graphics, fallback, pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, false);
				addClickRegion(pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, "nav", "prev");
			}
			if (canAdvance(1) && !hasNavigationElement(page, "NAV_NEXT")) {
				VisualElement fallback = defaultNavigationElement(true);
				renderNavigationArrow(graphics, fallback, pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, true);
				addClickRegion(pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, "nav", "next");
			}
		}
		drawCenteredD(graphics, Component.literal((pageIndex + 1) + " / " + CATEGORIES[categoryIndex].pages.length), pageX + PAGE_W / 2, pageY + PAGE_H - 14, 0xFF806B52);
	}

	private boolean hasNavigationElement(Page page, String type) {
		for (VisualElement element : page.elements)
			if (type.equals(element.type))
				return true;
		return false;
	}

	private VisualElement defaultNavigationElement(boolean next) {
		return new VisualElement(next ? "NAV_NEXT" : "NAV_PREV", next ? 226 : 12, 278, 18, 18, "", "LEFT", "", new String[0], 100, "", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE");
	}

	private void renderNavigationArrow(GuiGraphics graphics, VisualElement element, int x, int y, int w, int h, boolean right) {
		int bg = parseHexColor(element.buttonBackgroundColor, 0xFFFFF4D6);
		int border = parseHexColor(element.buttonBorderColor, 0xFF6D5237);
		int icon = parseHexColor(element.buttonTextColor, 0xFF6A5842);
		boolean hasImage = element.buttonImageName != null && !element.buttonImageName.isBlank();
		if ("IMAGE".equals(element.buttonStyle) && hasImage) {
			renderResourceImage(graphics, element.buttonImageName, element.buttonImageType, x, y, w, h);
			return;
		}
		switch (element.buttonStyle) {
			case "CLASSIC" -> {
				fillD(graphics, x, y, x + w, y + h, border);
				if (w > 4 && h > 4)
					fillD(graphics, x + 2, y + 2, x + w - 2, y + h - 2, bg);
			}
			case "FLAT" -> fillD(graphics, x, y, x + w, y + h, bg);
			case "OUTLINE" -> drawButtonBorder(graphics, x, y, w, h, border, 1);
			default -> {
			}
		}
		String glyphStyle = switch (element.align) {
			case "CENTER" -> "TRIANGLE";
			case "RIGHT" -> "DOUBLE";
			default -> "CHEVRON";
		};
		paintNavigationGlyphD(graphics, x, y, w, h, right, glyphStyle, icon);
	}

	/**
	 * Navigation glyphs are rasterized directly in final GUI pixels.
	 * This keeps the arrow proportions identical when the window becomes small:
	 * the logical rectangle is converted once, then the glyph is drawn inside
	 * that exact screen-space rectangle.
	 */
	private void paintNavigationGlyphD(GuiGraphics graphics, int x, int y, int w, int h, boolean right, String style, int color) {
		int rx = sx(x);
		int ry = sy(y);
		int rw = Math.max(3, sx(x + w) - rx);
		int rh = Math.max(3, sy(y + h) - ry);
		int cx = rx + rw / 2;
		int cy = ry + rh / 2;
		int radius = Math.max(2, Math.min(rw, rh) / 3);
		int thickness = Math.max(1, Math.min(rw, rh) / 9);
		if ("TRIANGLE".equals(style)) {
			int diameter = radius * 2;
			for (int step = 0; step <= diameter; step++) {
				int px = right ? cx - radius + step : cx + radius - step;
				int half = Math.max(0, radius - step / 2);
				graphics.fill(px, cy - half, px + thickness, cy + half + 1, color);
			}
			return;
		}
		paintChevronStrokeScreen(graphics, cx, cy, radius, thickness, right, color, 0);
		if ("DOUBLE".equals(style)) {
			int offset = Math.max(2, radius / 2 + 1);
			paintChevronStrokeScreen(graphics, cx, cy, radius, thickness, right, color, right ? -offset : offset);
		}
	}

	private void paintChevronStrokeScreen(GuiGraphics graphics, int cx, int cy, int radius, int thickness, boolean right, int color, int offset) {
		for (int i = 0; i <= radius; i++) {
			int px = (right ? cx - radius / 2 + i : cx + radius / 2 - i) + offset;
			graphics.fill(px, cy - radius + i, px + thickness, cy - radius + i + thickness, color);
			graphics.fill(px, cy + radius - i, px + thickness, cy + radius - i + thickness, color);
		}
	}

	private boolean canAdvance(int delta) {
		if (CATEGORIES.length == 0)
			return false;
		if (delta > 0 && HIDE_NEXT_ARROW_AT_CATEGORY_END && categoryIndex >= 0 && categoryIndex < CATEGORIES.length && pageIndex >= CATEGORIES[categoryIndex].pages.length - 1)
			return false;
		int c = categoryIndex;
		int p = pageIndex + delta;
		if (delta > 0) {
			while (c < CATEGORIES.length && p >= CATEGORIES[c].pages.length) {
				c++;
				p = 0;
			}
			return c < CATEGORIES.length;
		} else {
			while (c >= 0 && p < 0) {
				c--;
				if (c >= 0)
					p = CATEGORIES[c].pages.length - 1;
			}
			return c >= 0;
		}
	}

	private void renderRichTextBlock(GuiGraphics graphics, String markup, int x, int y, int width, int height, String align) {
		// Wrapping uses logical book coordinates, while glyph placement uses a
		// screen-pixel pen. This avoids cumulative rounding when uiScale < 1:
		// two neighboring glyphs can never collapse onto the same GUI pixels.
		List<Glyph> glyphs = buildGlyphs(markup == null ? "" : markup);
		List<Line> lines = wrapGlyphs(glyphs, Math.max(1, width));
		int cy = y;
		for (Line current : lines) {
			if (cy >= y + height)
				break;
			int offset = 0;
			if ("CENTER".equals(align))
				offset = Math.max(0, (width - current.width) / 2);
			else if ("RIGHT".equals(align))
				offset = Math.max(0, width - current.width);
			int screenCx = sx(x + offset);
			int screenCy = sy(cy);
			for (Glyph glyph : current.glyphs) {
				if (cy + glyph.height > y + height)
					break;
				float screenScale = crispTextScale(glyph.scale * uiScale);
				PoseStack pose = graphics.pose();
				pose.pushPose();
				pose.translate(screenCx, screenCy, 0);
				pose.scale(screenScale, screenScale, 1f);
				graphics.drawString(font, glyph.component, 0, 0, 0xFF38291E, false);
				pose.popPose();
				int screenAdvance = glyphScreenAdvance(glyph.component, glyph.scale);
				int screenHeight = glyphScreenHeight(glyph.scale);
				if (glyph.actionType != null && !glyph.raw.isBlank()) {
					addScreenClickRegion(screenCx, screenCy, screenAdvance, screenHeight, glyph.actionType, glyph.actionTarget);
				}
				screenCx += screenAdvance;
			}
			cy += Math.max(10, current.height);
		}
	}

	private int glyphScreenAdvance(Component component, float designScale) {
		float screenScale = crispTextScale(designScale * uiScale);
		int advance = Math.max(1, (int) Math.ceil(font.width(component) * screenScale));
		// A one-pixel breathing space at reduced layout scales prevents glyph
		// edge pixels from touching after raster quantization.
		if (uiScale < 0.999f)
			advance += 1;
		return advance;
	}

	private int glyphScreenHeight(float designScale) {
		float screenScale = crispTextScale(designScale * uiScale);
		return Math.max(1, (int) Math.ceil(9 * screenScale) + (uiScale < 0.999f ? 1 : 0));
	}

	private List<Line> wrapGlyphs(List<Glyph> glyphs, int maxWidth) {
		List<Line> lines = new ArrayList<>();
		Line current = new Line();
		int i = 0;
		while (i < glyphs.size()) {
			Glyph glyph = glyphs.get(i);
			if (glyph.newline) {
				lines.add(current);
				current = new Line();
				i++;
				continue;
			}
			if (glyph.raw.isBlank()) {
				// Do not carry leading spaces to a freshly wrapped line.
				if (!current.glyphs.isEmpty()) {
					if (current.width + glyph.width > maxWidth) {
						lines.add(current);
						current = new Line();
					} else {
						current.add(glyph);
					}
				}
				i++;
				continue;
			}
			// Gather one word. It is placed as a unit whenever it fits; very long
			// words are hard-wrapped character by character so text can never escape
			// the configured text-zone width.
			List<Glyph> word = new ArrayList<>();
			int wordWidth = 0;
			int j = i;
			while (j < glyphs.size()) {
				Glyph next = glyphs.get(j);
				if (next.newline || next.raw.isBlank())
					break;
				word.add(next);
				wordWidth += next.width;
				j++;
			}
			if (!current.glyphs.isEmpty() && current.width + wordWidth > maxWidth) {
				lines.add(current);
				current = new Line();
			}
			if (wordWidth <= maxWidth) {
				for (Glyph part : word)
					current.add(part);
			} else {
				for (Glyph part : word) {
					if (!current.glyphs.isEmpty() && current.width + part.width > maxWidth) {
						lines.add(current);
						current = new Line();
					}
					current.add(part);
				}
			}
			i = j;
		}
		lines.add(current);
		return lines;
	}

	private List<Glyph> buildGlyphs(String markup) {
		List<Glyph> result = new ArrayList<>();
		List<RichToken> tokens = parse(markup);
		for (RichToken token : tokens) {
			State state = token.state;
			float designScale = Math.max(0.05f, state.size / 9.0f);
			for (int i = 0; i < token.text.length();) {
				int ch = token.text.codePointAt(i);
				i += Character.charCount(ch);
				if (ch == '\r')
					continue;
				if (ch == '\n') {
					result.add(new Glyph("", Component.empty(), 1f, 0, 10, true, null, null));
					continue;
				}
				String raw = new String(Character.toChars(ch));
				Component component = styledComponent(raw, state);
				// crispTextScale() may quantize the requested scale to a whole
				// physical-pixel multiple. In a small window that quantized scale
				// can be slightly larger than designScale * uiScale. Compute the
				// logical advance from the *actual* render scale so the next glyph
				// can never start before the previous one has finished.
				int screenAdvance = glyphScreenAdvance(component, designScale);
				int screenHeight = glyphScreenHeight(designScale);
				int gw = Math.max(1, (int) Math.ceil(screenAdvance / Math.max(0.05f, uiScale)));
				int gh = Math.max(1, (int) Math.ceil(screenHeight / Math.max(0.05f, uiScale)));
				result.add(new Glyph(raw, component, designScale, gw, gh, false, state.actionType, state.actionTarget));
			}
		}
		return result;
	}

	private Component styledComponent(String text, State state) {
		Style style = Style.EMPTY.withBold(state.bold).withItalic(state.italic).withUnderlined(state.underline || state.actionType != null).withStrikethrough(state.strike).withObfuscated(state.obfuscated);
		if (state.color != null)
			style = style.withColor(state.color);
		else if (state.actionType != null)
			style = style.withColor(0x2F62C9);
		return Component.literal(text).withStyle(style);
	}

	private static List<RichToken> parse(String markup) {
		List<RichToken> tokens = new ArrayList<>();
		Deque<StateFrame> stack = new ArrayDeque<>();
		State state = new State();
		Matcher matcher = TAG_PATTERN.matcher(markup);
		int last = 0;
		while (matcher.find()) {
			if (matcher.start() > last)
				tokens.add(new RichToken(markup.substring(last, matcher.start()), state.copy()));
			boolean closing = !matcher.group(1).isEmpty();
			String tag = matcher.group(2).toLowerCase(Locale.ROOT);
			String arg = matcher.group(3);
			if (closing) {
				boolean hasMatchingOpening = false;
				for (StateFrame frame : stack) {
					if (frame.tag.equals(tag)) {
						hasMatchingOpening = true;
						break;
					}
				}
				if (hasMatchingOpening) {
					while (!stack.isEmpty()) {
						StateFrame frame = stack.pop();
						state = frame.previous;
						if (frame.tag.equals(tag))
							break;
					}
				}
			} else {
				stack.push(new StateFrame(tag, state.copy()));
				switch (tag) {
					case "b" -> state.bold = true;
					case "i" -> state.italic = true;
					case "u" -> state.underline = true;
					case "s" -> state.strike = true;
					case "obf" -> state.obfuscated = true;
					case "size" -> state.size = safeInt(arg, DEFAULT_SIZE, 6, 48);
					case "color" -> state.color = parseColor(arg);
					case "url" -> {
						state.actionType = "url";
						state.actionTarget = arg == null ? "" : arg;
					}
					case "page" -> {
						state.actionType = "page";
						state.actionTarget = arg == null ? "" : arg;
					}
				}
			}
			last = matcher.end();
		}
		if (last < markup.length())
			tokens.add(new RichToken(markup.substring(last), state.copy()));
		return tokens;
	}

	private static Integer parseColor(String color) {
		try {
			if (color != null && color.matches("#[0-9a-fA-F]{6}"))
				return Integer.parseInt(color.substring(1), 16);
		} catch (Exception ignored) {
		}
		return null;
	}

	private static int safeInt(String value, int fallback, int min, int max) {
		try {
			return Math.max(min, Math.min(max, Integer.parseInt(value)));
		} catch (Exception ignored) {
			return fallback;
		}
	}

	private Page currentPage() {
		if (CATEGORIES.length == 0)
			return null;
		categoryIndex = Math.max(0, Math.min(categoryIndex, CATEGORIES.length - 1));
		Category category = CATEGORIES[categoryIndex];
		if (category.pages.length == 0)
			return null;
		pageIndex = Math.max(0, Math.min(pageIndex, category.pages.length - 1));
		return category.pages[pageIndex];
	}

	private void selectCategoryById(String id) {
		for (int i = 0; i < CATEGORIES.length; i++) {
			if (CATEGORIES[i].id.equals(id)) {
				categoryIndex = i;
				categoryListPage = i / CATEGORY_ROWS;
				pageIndex = 0;
				return;
			}
		}
	}

	private void selectPageById(String id) {
		for (int c = 0; c < CATEGORIES.length; c++) {
			for (int p = 0; p < CATEGORIES[c].pages.length; p++) {
				if (CATEGORIES[c].pages[p].id.equals(id)) {
					categoryIndex = c;
					categoryListPage = c / CATEGORY_ROWS;
					pageIndex = p;
					return;
				}
			}
		}
	}

	private void advancePage(int delta) {
		if (!canAdvance(delta))
			return;
		int c = categoryIndex;
		int p = pageIndex + delta;
		if (delta > 0) {
			while (c < CATEGORIES.length && p >= CATEGORIES[c].pages.length) {
				c++;
				p = 0;
			}
			if (c >= CATEGORIES.length)
				return;
		} else {
			while (c >= 0 && p < 0) {
				c--;
				if (c >= 0)
					p = CATEGORIES[c].pages.length - 1;
			}
			if (c < 0)
				return;
		}
		categoryIndex = c;
		categoryListPage = c / CATEGORY_ROWS;
		pageIndex = p;
	}

	/**
	 * External links always require explicit confirmation. The link is marked as
	 * untrusted so Minecraft displays its standard security warning and the URL
	 * before the browser is opened.
	 */
	private void openExternalLinkWithWarning(String url) {
		Minecraft minecraft = Minecraft.getInstance();
		minecraft.setScreen(new ConfirmLinkScreen(confirmed -> {
			if (confirmed)
				Util.getPlatform().openUri(url);
			minecraft.setScreen(this);
		}, url, false));
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0) {
			for (int i = clickRegions.size() - 1; i >= 0; i--) {
				ClickRegion region = clickRegions.get(i);
				if (!region.contains(mouseX, mouseY))
					continue;
				switch (region.type) {
					case "category" -> selectCategoryById(region.target);
					case "category_list" -> changeCategoryListPage("next".equals(region.target) ? 1 : -1);
					case "nav" -> advancePage("next".equals(region.target) ? 1 : -1);
					case "page" -> selectPageById(region.target);
					case "url" -> {
						if (region.target.startsWith("https://") || region.target.startsWith("http://")) {
							openExternalLinkWithWarning(region.target);
						}
					}
				}
				return true;
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private record Category(String id, String name, Page[] pages) {
	}

	private record Page(String id, String title, boolean showTitle, VisualElement[] elements) {
	}

	private record VisualElement(String type, int x, int y, int width, int height, String content, String align, String mediaName, String[] frames, int frameDelay, String label, String targetCategoryId, String targetPageId, String buttonStyle,
			String buttonBackgroundColor, String buttonBorderColor, String buttonTextColor, String buttonImageName, String buttonImageType, String buttonImageMode) {
	}

	private record StateFrame(String tag, State previous) {
	}

	private record RichToken(String text, State state) {
	}

	private record Glyph(String raw, Component component, float scale, int width, int height, boolean newline, String actionType, String actionTarget) {
		static Glyph newLineGlyph() {
			return new Glyph("", Component.empty(), 1f, 0, 10, true, null, null);
		}
	}

	private record ClickRegion(int x, int y, int width, int height, String type, String target) {
		boolean contains(double mx, double my) {
			return mx >= x && mx < x + width && my >= y && my < y + height;
		}
	}

	private static final class Line {
		final List<Glyph> glyphs = new ArrayList<>();
		int width;
		int height = 0;

		void add(Glyph glyph) {
			glyphs.add(glyph);
			width += glyph.width;
			height = Math.max(height, glyph.height);
		}
	}

	private static final class State {
		boolean bold;
		boolean italic;
		boolean underline;
		boolean strike;
		boolean obfuscated;
		int size = DEFAULT_SIZE;
		Integer color;
		String actionType;
		String actionTarget;

		State copy() {
			State copy = new State();
			copy.bold = bold;
			copy.italic = italic;
			copy.underline = underline;
			copy.strike = strike;
			copy.obfuscated = obfuscated;
			copy.size = size;
			copy.color = color;
			copy.actionType = actionType;
			copy.actionTarget = actionTarget;
			return copy;
		}
	}
}