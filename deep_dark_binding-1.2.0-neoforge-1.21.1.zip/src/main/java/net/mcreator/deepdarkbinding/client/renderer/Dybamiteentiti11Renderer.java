package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti11Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti11Renderer extends MobRenderer<Dybamiteentiti11Entity, Modeldynamite<Dybamiteentiti11Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite11png.png");

	public Dybamiteentiti11Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti11Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti11Entity entity) {
		return entityTexture;
	}
}