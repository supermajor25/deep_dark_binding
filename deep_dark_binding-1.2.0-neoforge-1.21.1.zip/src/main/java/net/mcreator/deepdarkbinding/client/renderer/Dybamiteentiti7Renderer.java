package net.mcreator.deepdarkbinding.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.deepdarkbinding.entity.Dybamiteentiti7Entity;
import net.mcreator.deepdarkbinding.client.model.Modeldynamite;

public class Dybamiteentiti7Renderer extends MobRenderer<Dybamiteentiti7Entity, Modeldynamite<Dybamiteentiti7Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_dark_binding:textures/entities/dynamite8.png");

	public Dybamiteentiti7Renderer(EntityRendererProvider.Context context) {
		super(context, new Modeldynamite<Dybamiteentiti7Entity>(context.bakeLayer(Modeldynamite.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dybamiteentiti7Entity entity) {
		return entityTexture;
	}
}