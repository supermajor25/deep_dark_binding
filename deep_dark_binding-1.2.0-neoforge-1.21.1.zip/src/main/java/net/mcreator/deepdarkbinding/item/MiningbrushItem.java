package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class MiningbrushItem extends Item {
	public MiningbrushItem() {
		super(new Item.Properties().stacksTo(1));
	}
}