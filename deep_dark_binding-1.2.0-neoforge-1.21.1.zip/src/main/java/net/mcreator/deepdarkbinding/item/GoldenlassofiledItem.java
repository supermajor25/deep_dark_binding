package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.deepdarkbinding.procedures.ResetProcedure;

public class GoldenlassofiledItem extends Item {
	public GoldenlassofiledItem() {
		super(new Item.Properties());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		ResetProcedure.execute(entity, sourceentity, itemstack);
		return retval;
	}
}