package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

import net.mcreator.deepdarkbinding.procedures.BlazestaffEvenementAuClicDroitDansLairProcedure;

public class BlazestaffItem extends Item {
	public BlazestaffItem() {
		super(new Item.Properties().durability(32).rarity(Rarity.RARE));
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack itemstack, BlockState state) {
		return true;
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		BlazestaffEvenementAuClicDroitDansLairProcedure.execute(world, entity, ar.getObject());
		return ar;
	}
}