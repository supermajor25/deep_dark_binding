package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class PoisonessencevialItem extends Item {
	public PoisonessencevialItem() {
		super(new Item.Properties().stacksTo(16));
	}
}