package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofminingItem extends Item {
	public RingofminingItem() {
		super(new Item.Properties().stacksTo(1));
	}
}