package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class ColaleefItem extends Item {
	public ColaleefItem() {
		super(new Item.Properties());
	}
}