package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class NauseaessencevialItem extends Item {
	public NauseaessencevialItem() {
		super(new Item.Properties().stacksTo(16));
	}
}