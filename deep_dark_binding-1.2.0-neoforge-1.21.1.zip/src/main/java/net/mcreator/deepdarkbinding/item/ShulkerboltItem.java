package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class ShulkerboltItem extends Item {
	public ShulkerboltItem() {
		super(new Item.Properties());
	}
}