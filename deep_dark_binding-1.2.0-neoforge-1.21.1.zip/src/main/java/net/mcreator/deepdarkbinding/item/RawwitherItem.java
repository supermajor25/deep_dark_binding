package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RawwitherItem extends Item {
	public RawwitherItem() {
		super(new Item.Properties());
	}
}