package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class BlindnessessencevialItem extends Item {
	public BlindnessessencevialItem() {
		super(new Item.Properties().stacksTo(16));
	}
}