package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class PiglinlordsamuletItem extends Item {
	public PiglinlordsamuletItem() {
		super(new Item.Properties().stacksTo(1));
	}
}