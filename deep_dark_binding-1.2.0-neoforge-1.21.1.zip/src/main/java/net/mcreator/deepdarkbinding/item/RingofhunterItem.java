package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofhunterItem extends Item {
	public RingofhunterItem() {
		super(new Item.Properties().stacksTo(1));
	}
}