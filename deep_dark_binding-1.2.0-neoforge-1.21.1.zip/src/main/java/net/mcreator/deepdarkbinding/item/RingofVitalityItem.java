package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofVitalityItem extends Item {
	public RingofVitalityItem() {
		super(new Item.Properties().stacksTo(1));
	}
}