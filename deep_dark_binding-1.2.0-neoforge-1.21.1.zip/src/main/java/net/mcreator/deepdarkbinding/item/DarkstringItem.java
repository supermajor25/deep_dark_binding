package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class DarkstringItem extends Item {
	public DarkstringItem() {
		super(new Item.Properties());
	}
}