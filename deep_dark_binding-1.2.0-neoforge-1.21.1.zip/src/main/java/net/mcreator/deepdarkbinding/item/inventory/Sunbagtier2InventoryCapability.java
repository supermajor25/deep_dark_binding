package net.mcreator.deepdarkbinding.item.inventory;

import net.neoforged.neoforge.items.ComponentItemHandler;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.common.MutableDataComponentHolder;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.component.DataComponents;

import net.mcreator.deepdarkbinding.world.inventory.Sunbagtier2interfaceMenu;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModItems;

import javax.annotation.Nonnull;

@EventBusSubscriber
public class Sunbagtier2InventoryCapability extends ComponentItemHandler {
	@SubscribeEvent
	public static void onItemDropped(ItemTossEvent event) {
		if (event.getEntity().getItem().getItem() == DeepDarkBindingModItems.SUNBAGTIER_2.get()) {
			Player player = event.getPlayer();
			if (player.containerMenu instanceof Sunbagtier2interfaceMenu)
				player.closeContainer();
		}
	}

	public Sunbagtier2InventoryCapability(MutableDataComponentHolder parent) {
		super(parent, DataComponents.CONTAINER, 55);
	}

	@Override
	public int getSlotLimit(int slot) {
		return 64;
	}

	@Override
	public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
		return stack.getItem() != DeepDarkBindingModItems.SUNBAGTIER_2.get();
	}

	@Override
	public ItemStack getStackInSlot(int slot) {
		return super.getStackInSlot(slot).copy();
	}
}