package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RawfireItem extends Item {
	public RawfireItem() {
		super(new Item.Properties());
	}
}