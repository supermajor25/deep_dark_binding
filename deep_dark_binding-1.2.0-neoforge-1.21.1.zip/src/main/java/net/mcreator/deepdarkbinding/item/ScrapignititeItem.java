package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class ScrapignititeItem extends Item {
	public ScrapignititeItem() {
		super(new Item.Properties().fireResistant());
	}
}