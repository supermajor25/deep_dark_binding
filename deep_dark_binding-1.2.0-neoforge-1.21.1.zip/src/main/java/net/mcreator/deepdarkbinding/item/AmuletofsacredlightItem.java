package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class AmuletofsacredlightItem extends Item {
	public AmuletofsacredlightItem() {
		super(new Item.Properties().stacksTo(1));
	}
}