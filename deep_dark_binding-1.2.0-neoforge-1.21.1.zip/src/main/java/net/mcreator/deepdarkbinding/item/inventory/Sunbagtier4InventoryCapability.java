package net.mcreator.deepdarkbinding.item.inventory;

import net.neoforged.neoforge.items.ComponentItemHandler;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.common.MutableDataComponentHolder;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.component.DataComponents;

import net.mcreator.deepdarkbinding.world.inventory.Sunbagtier4interfaceMenu;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModItems;

import javax.annotation.Nonnull;

@EventBusSubscriber
public class Sunbagtier4InventoryCapability extends ComponentItemHandler {
	@SubscribeEvent
	public static void onItemDropped(ItemTossEvent event) {
		if (event.getEntity().getItem().getItem() == DeepDarkBindingModItems.SUNBAGTIER_4.get()) {
			Player player = event.getPlayer();
			if (player.containerMenu instanceof Sunbagtier4interfaceMenu)
				player.closeContainer();
		}
	}

	public Sunbagtier4InventoryCapability(MutableDataComponentHolder parent) {
		super(parent, DataComponents.CONTAINER, 106);
	}

	@Override
	public int getSlotLimit(int slot) {
		return 64;
	}

	@Override
	public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
		return stack.getItem() != DeepDarkBindingModItems.SUNBAGTIER_4.get();
	}

	@Override
	public ItemStack getStackInSlot(int slot) {
		return super.getStackInSlot(slot).copy();
	}
}