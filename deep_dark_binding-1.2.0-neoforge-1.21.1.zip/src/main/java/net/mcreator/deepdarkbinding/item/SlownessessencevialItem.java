package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class SlownessessencevialItem extends Item {
	public SlownessessencevialItem() {
		super(new Item.Properties().stacksTo(16));
	}
}