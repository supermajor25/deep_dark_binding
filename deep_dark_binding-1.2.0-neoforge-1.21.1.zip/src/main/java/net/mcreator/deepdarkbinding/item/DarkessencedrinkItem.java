package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.deepdarkbinding.procedures.DarkessencedrinkLeJoueurTermineDutiliserLitemProcedure;
import net.mcreator.deepdarkbinding.init.DeepDarkBindingModItems;

public class DarkessencedrinkItem extends Item {
	public DarkessencedrinkItem() {
		super(new Item.Properties().stacksTo(1).food((new FoodProperties.Builder()).nutrition(2).saturationModifier(0.5f).alwaysEdible().build()));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.DRINK;
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = new ItemStack(DeepDarkBindingModItems.CANETTE.get());
		super.finishUsingItem(itemstack, world, entity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		DarkessencedrinkLeJoueurTermineDutiliserLitemProcedure.execute(entity);
		if (itemstack.isEmpty()) {
			return retval;
		} else {
			if (entity instanceof Player player && !player.getAbilities().instabuild) {
				if (!player.getInventory().add(retval))
					player.drop(retval, false);
			}
			return itemstack;
		}
	}
}