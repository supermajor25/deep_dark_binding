package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class Ring1Item extends Item {
	public Ring1Item() {
		super(new Item.Properties().stacksTo(1));
	}
}