package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class AmuletofpurityItem extends Item {
	public AmuletofpurityItem() {
		super(new Item.Properties().stacksTo(1));
	}
}