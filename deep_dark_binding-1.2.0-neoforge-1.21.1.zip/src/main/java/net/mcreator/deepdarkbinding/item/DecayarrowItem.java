package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class DecayarrowItem extends Item {
	public DecayarrowItem() {
		super(new Item.Properties());
	}
}