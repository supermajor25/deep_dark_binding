package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class VenomitenuggetItem extends Item {
	public VenomitenuggetItem() {
		super(new Item.Properties());
	}
}