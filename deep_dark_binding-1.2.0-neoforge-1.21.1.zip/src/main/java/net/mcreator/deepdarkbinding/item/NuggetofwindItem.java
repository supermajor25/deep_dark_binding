package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class NuggetofwindItem extends Item {
	public NuggetofwindItem() {
		super(new Item.Properties());
	}
}