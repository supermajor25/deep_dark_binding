package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class CookedsausageItem extends Item {
	public CookedsausageItem() {
		super(new Item.Properties().food((new FoodProperties.Builder()).nutrition(7).saturationModifier(6f).build()));
	}
}