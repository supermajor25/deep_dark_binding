package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GoldstringItem extends Item {
	public GoldstringItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}