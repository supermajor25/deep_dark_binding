package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class ThunderboltitemItem extends Item {
	public ThunderboltitemItem() {
		super(new Item.Properties());
	}
}