package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class WitheressencevialItem extends Item {
	public WitheressencevialItem() {
		super(new Item.Properties().stacksTo(16).rarity(Rarity.RARE));
	}
}