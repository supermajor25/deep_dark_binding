package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class DiamondstringItem extends Item {
	public DiamondstringItem() {
		super(new Item.Properties());
	}
}