package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class IronstringItem extends Item {
	public IronstringItem() {
		super(new Item.Properties());
	}
}