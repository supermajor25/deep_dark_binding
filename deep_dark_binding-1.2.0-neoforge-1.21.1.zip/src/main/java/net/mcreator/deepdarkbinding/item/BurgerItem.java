package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class BurgerItem extends Item {
	public BurgerItem() {
		super(new Item.Properties().food((new FoodProperties.Builder()).nutrition(10).saturationModifier(12f).build()));
	}
}