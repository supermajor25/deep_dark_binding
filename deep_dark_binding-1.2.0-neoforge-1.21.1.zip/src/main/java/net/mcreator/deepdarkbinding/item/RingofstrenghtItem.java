package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofstrenghtItem extends Item {
	public RingofstrenghtItem() {
		super(new Item.Properties().stacksTo(1));
	}
}