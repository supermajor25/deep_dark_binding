package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class WitheringotItem extends Item {
	public WitheringotItem() {
		super(new Item.Properties().rarity(Rarity.RARE));
	}
}