package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class WeaknessessencevialItem extends Item {
	public WeaknessessencevialItem() {
		super(new Item.Properties().stacksTo(16));
	}
}