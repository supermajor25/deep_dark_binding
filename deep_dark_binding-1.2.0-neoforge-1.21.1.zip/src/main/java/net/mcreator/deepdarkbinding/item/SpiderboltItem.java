package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class SpiderboltItem extends Item {
	public SpiderboltItem() {
		super(new Item.Properties());
	}
}