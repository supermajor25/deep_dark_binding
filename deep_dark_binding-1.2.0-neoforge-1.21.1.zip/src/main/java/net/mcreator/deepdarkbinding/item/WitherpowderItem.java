package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class WitherpowderItem extends Item {
	public WitherpowderItem() {
		super(new Item.Properties().rarity(Rarity.RARE));
	}
}