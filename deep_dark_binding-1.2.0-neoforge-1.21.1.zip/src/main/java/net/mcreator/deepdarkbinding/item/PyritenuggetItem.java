package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class PyritenuggetItem extends Item {
	public PyritenuggetItem() {
		super(new Item.Properties());
	}
}