package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.deepdarkbinding.procedures.FreshwatercanLeJoueurTermineDutiliserLitemProcedure;

public class FreshwatercanItem extends Item {
	public FreshwatercanItem() {
		super(new Item.Properties().stacksTo(1).food((new FoodProperties.Builder()).nutrition(1).saturationModifier(0f).build()));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.DRINK;
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		FreshwatercanLeJoueurTermineDutiliserLitemProcedure.execute(entity);
		return retval;
	}
}