package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class FireingotItem extends Item {
	public FireingotItem() {
		super(new Item.Properties());
	}
}