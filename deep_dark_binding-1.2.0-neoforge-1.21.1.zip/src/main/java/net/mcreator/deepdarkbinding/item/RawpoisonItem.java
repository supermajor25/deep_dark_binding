package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RawpoisonItem extends Item {
	public RawpoisonItem() {
		super(new Item.Properties());
	}
}