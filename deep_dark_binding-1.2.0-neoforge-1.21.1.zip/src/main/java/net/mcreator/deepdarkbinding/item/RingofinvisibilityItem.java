package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofinvisibilityItem extends Item {
	public RingofinvisibilityItem() {
		super(new Item.Properties().stacksTo(1));
	}
}