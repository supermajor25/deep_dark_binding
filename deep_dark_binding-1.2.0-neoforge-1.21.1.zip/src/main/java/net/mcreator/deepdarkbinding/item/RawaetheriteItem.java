package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RawaetheriteItem extends Item {
	public RawaetheriteItem() {
		super(new Item.Properties());
	}
}