package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class PoisoningotItem extends Item {
	public PoisoningotItem() {
		super(new Item.Properties());
	}
}