package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class WitheritenuggetItem extends Item {
	public WitheritenuggetItem() {
		super(new Item.Properties());
	}
}