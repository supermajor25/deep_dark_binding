package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class IngotofwindItem extends Item {
	public IngotofwindItem() {
		super(new Item.Properties());
	}
}