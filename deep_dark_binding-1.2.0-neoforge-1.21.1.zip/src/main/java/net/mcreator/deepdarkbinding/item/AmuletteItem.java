package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class AmuletteItem extends Item {
	public AmuletteItem() {
		super(new Item.Properties());
	}
}