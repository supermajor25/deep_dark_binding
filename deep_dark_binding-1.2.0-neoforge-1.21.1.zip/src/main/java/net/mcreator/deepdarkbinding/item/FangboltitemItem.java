package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class FangboltitemItem extends Item {
	public FangboltitemItem() {
		super(new Item.Properties());
	}
}