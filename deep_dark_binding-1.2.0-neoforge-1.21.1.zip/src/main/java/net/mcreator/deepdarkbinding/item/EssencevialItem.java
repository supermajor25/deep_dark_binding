package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class EssencevialItem extends Item {
	public EssencevialItem() {
		super(new Item.Properties());
	}
}