package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class IgnititeingotItem extends Item {
	public IgnititeingotItem() {
		super(new Item.Properties());
	}
}