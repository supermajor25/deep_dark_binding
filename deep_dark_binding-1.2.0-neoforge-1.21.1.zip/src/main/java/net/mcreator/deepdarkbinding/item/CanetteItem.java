package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class CanetteItem extends Item {
	public CanetteItem() {
		super(new Item.Properties());
	}
}