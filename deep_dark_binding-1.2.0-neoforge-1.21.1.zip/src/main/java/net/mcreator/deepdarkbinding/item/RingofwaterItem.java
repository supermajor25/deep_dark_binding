package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofwaterItem extends Item {
	public RingofwaterItem() {
		super(new Item.Properties().stacksTo(1));
	}
}