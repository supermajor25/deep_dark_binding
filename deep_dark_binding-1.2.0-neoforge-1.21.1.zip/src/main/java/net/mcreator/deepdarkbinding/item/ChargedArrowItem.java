package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class ChargedArrowItem extends Item {
	public ChargedArrowItem() {
		super(new Item.Properties());
	}
}