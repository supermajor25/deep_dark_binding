package net.mcreator.deepdarkbinding.item;

import net.minecraft.world.item.Item;

public class RingofspeedItem extends Item {
	public RingofspeedItem() {
		super(new Item.Properties().stacksTo(1));
	}
}